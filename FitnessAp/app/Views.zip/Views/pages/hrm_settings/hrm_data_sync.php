<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<!-- <?php //echo $block_header; 
						?> -->

				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Sync Data From HRM</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<div class="header">
								<!-- <h2>List of systems that are currently connected to the EDMS's API.</h2> -->
							</div>
							<div class="body">
								<div style="margin-top: -35px;">
									<div class="alert alert-warning">
										Following data from HRM system will be synced to EDMS every hour automatically. <br> But you can sync them manually by clicking the " <strong>Sync Now</strong> " button.
									</div>
									<hr>
									<div class="row">
										<div class="col-sm-6">
											<div class="card border">
												<div class="card-body">
													<h6 class="card-title"><strong>Locations</strong></h6>
													<p class="card-text" style="margin-top: -10px;"><?php echo 'Last Synced on ' . date_format(date_create($last_sync_dates[0]['locations_last_synced']), 'Y-m-d') . ' at ' . date_format(date_create($last_sync_dates[0]['locations_last_synced']), 'h:i A'); ?></p>
													<button id="sync_locations" class="btn btn-dark">Sync Now</button>
												</div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="card border">
												<div class="card-body">
													<h6 class="card-title"><strong>Cost Centers</strong></h6>
													<p class="card-text" style="margin-top: -10px;"><?php echo 'Last Synced on ' . date_format(date_create($last_sync_dates[0]['cost_centers_last_synced']), 'Y-m-d') . ' at ' . date_format(date_create($last_sync_dates[0]['cost_centers_last_synced']), 'h:i A'); ?></p>
													<button id="sync_cost_centers" class="btn btn-dark">Sync Now</button>
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="card border">
												<div class="card-body">
													<h6 class="card-title"><strong>Designations</strong></h6>
													<p class="card-text" style="margin-top: -10px;"><?php echo 'Last Synced on ' . date_format(date_create($last_sync_dates[0]['designations_last_synced']), 'Y-m-d') . ' at ' . date_format(date_create($last_sync_dates[0]['designations_last_synced']), 'h:i A'); ?></p>
													<button id="sync_designations" class="btn btn-dark">Sync Now</button>
												</div>
											</div>
										</div>
										<div class="col-sm-6">
											<div class="card border">
												<div class="card-body">
													<h6 class="card-title"><strong>Employees</strong></h6>
													<p class="card-text" style="margin-top: -10px;"><?php echo 'Last Synced on ' . date_format(date_create($last_sync_dates[0]['employees_last_synced']), 'Y-m-d') . ' at ' . date_format(date_create($last_sync_dates[0]['employees_last_synced']), 'h:i A'); ?></p>
													<button id="sync_employees" class="btn btn-dark">Sync Now</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Loading Modal -->
				<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered">
						<div class="modal-content" style="width: 350px; height: 150px; margin-left: 100px; margin-bottom: 100px;">
							<div class="modal-body">
								<div class="d-flex flex-column text-center align-items-center justify-content-center mt-3">
									<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
									<div class="d-flex flex-column">
										<label class="form-label text-dark mt-2">Syncing in Progress... This may take a while.</label>
										<label class="form-label text-danger mt-2">DON'T REFRESH THE PAGE!</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>

	<script>
		$(document).ready(function() {
			// Sync locations
			$('#sync_locations').click(function() {
				$.ajax({
					url: '<?= base_url('hrm_settings/data_sync/sync_locations') ?>',
					type: 'GET',
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
						$('#sync_locations').html('Syncing...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_locations').html('Sync Now');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload();
								}
							});
						} else {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
					},
					error: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_locations').html('Sync Now');
						alert('Error syncing locations');
					}
				});
			});

			// Sync cost centers
			$('#sync_cost_centers').click(function() {
				$.ajax({
					url: '<?= base_url('hrm_settings/data_sync/sync_cost_centers') ?>',
					type: 'GET',
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
						$('#sync_cost_centers').html('Syncing...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_cost_centers').html('Sync Now');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload();
								}
							});
						} else {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
					},
					error: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_cost_centers').html('Sync Now');
						alert('Error syncing cost centers');
					}
				});
			});

			// Sync designations
			$('#sync_designations').click(function() {
				$.ajax({
					url: '<?= base_url('hrm_settings/data_sync/sync_designations') ?>',
					type: 'GET',
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
						$('#sync_designations').html('Syncing...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_designations').html('Sync Now');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload();
								}
							});
						} else {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
					},
					error: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_designations').html('Sync Now');
						alert('Error syncing designations');
					}
				});
			});

			// Sync employees
			$('#sync_employees').click(function() {
				$.ajax({
					url: '<?= base_url('hrm_settings/data_sync/sync_employees') ?>',
					type: 'GET',
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
						$('#sync_employees').html('Syncing...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_employees').html('Sync Now');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload();
								}
							});
						} else {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
					},
					error: function(response) {
						$('#loadingModal').modal('hide');
						$('#sync_employees').html('Sync Now');
						alert('Error syncing employees');
					}
				});
			});
		});
	</script>
</body>

</html>