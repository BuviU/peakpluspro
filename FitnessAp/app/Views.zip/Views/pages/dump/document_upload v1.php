<!doctype html>
<html lang="en">

<head>
	<title>:: NWSDB ::</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
	<meta name="author" content="WrapTheme, design by: ThemeMakker.com">

	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<!-- VENDOR CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/sweetalert/sweetalert.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/select2/select2.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/color_skins.css">

	<script src="https://cdn.asprise.com/scannerjs/scanner.js" type="text/javascript"></script>

	<script>
		//
		// Please read scanner.js developer's guide at: http://asprise.com/document-scan-upload-image-browser/ie-chrome-firefox-scanner-docs.html
		//

		var document_scanned_successfully = false;

		/** Scan: output PDF original and JPG thumbnails */
		function scanToPdfWithThumbnails() {
			if (!document_scanned_successfully) {
				scanner.scan(displayImagesOnPage, {
					"output_settings": [{
							"type": "return-base64",
							"format": "pdf",
							"pdf_text_line": "By ${USERNAME} on ${DATETIME}"
						},
						{
							"type": "return-base64-thumbnail",
							"format": "jpg",
							"thumbnail_height": 200
						}
					]
				});
			}
			else{
				Swal.fire({
					icon: 'warning',
					title: 'Warning',
					text: 'There is a scanned document already in the queue. Please remove that scanned document and try again!',
				});
			}
		}

		/** Processes the scan result */
		function displayImagesOnPage(successful, mesg, response) {
			if (!successful) { // On error
				console.error('Failed: ' + mesg);
				document_scanned_successfully = false;
				document.getElementById('doc_to_upload').innerHTML = 'None';
				document.getElementById('doc_to_upload_type').innerHTML = 'None';
				$('#remove_scanned_doc').addClass('d-none');
				return;
			}

			if (successful && mesg != null && mesg.toLowerCase().indexOf('user cancel') >= 0) { // User cancelled.
				console.info('User cancelled');
				document_scanned_successfully = false;
				document.getElementById('doc_to_upload').innerHTML = 'None';
				document.getElementById('doc_to_upload_type').innerHTML = 'None';
				$('#remove_scanned_doc').addClass('d-none');
				return;
			}

			var scannedImages = scanner.getScannedImages(response, true, false); // returns an array of ScannedImage
			for (var i = 0;
				(scannedImages instanceof Array) && i < scannedImages.length; i++) {
				var scannedImage = scannedImages[i];
				processOriginal(scannedImage);
			}
			var thumbnails = scanner.getScannedImages(response, false, true); // returns an array of ScannedImage
			for (var i = 0;
				(thumbnails instanceof Array) && i < thumbnails.length; i++) {
				var thumbnail = thumbnails[i];
				processThumbnail(thumbnail);
			}

			document_scanned_successfully = true;
			fileInput.value = null;
			document.getElementById('doc_to_upload').innerHTML = thumbnails.length + ' Page(s) Scanned.';
			document.getElementById('doc_to_upload_type').innerHTML = 'PDF';
			$('#remove_scanned_doc').removeClass('d-none');
			Swal.fire({
				icon: 'success',
				title: 'Success',
				text: 'Document Scanned Successfully.',
			});
			// dismiss the modal
			$('#staticBackdrop').modal('hide');
		}

		/** Images scanned so far. */
		var imagesScanned = [];

		/** Processes an original */
		function processOriginal(scannedImage) {
			imagesScanned.push(scannedImage);
			// set value of hidden input field - base64_pdf
			$('#base64_pdf').val(imagesScanned[0].src);
		}

		/** Processes a thumbnail */
		function processThumbnail(scannedImage) {
			var elementImg = scanner.createDomElementFromModel({
				'name': 'img',
				'attributes': {
					'class': 'scanned view',
					'src': scannedImage.src,
					'onclick': 'openPDF()'
				}
			});
			document.getElementById('images').appendChild(elementImg);
			document.getElementById('scannedImagesCard').style.display = 'block';
		}

		/** Upload scanned images by submitting the form */
		function submitFormWithScannedImages() {
			if (scanner.submitFormWithImages('form1', imagesScanned, function(xhr) {
					if (xhr.readyState == 4) { // 4: request finished and response is ready
						document.getElementById('server_response').innerHTML = "<h2>Response from the server: </h2>" + xhr.responseText;
						document.getElementById('images').innerHTML = ''; // clear images
						imagesScanned = [];
					}
				})) {
				document.getElementById('server_response').innerHTML = "Submitting, please stand by ...";
			} else {
				document.getElementById('server_response').innerHTML = "Form submission cancelled. Please scan first.";
			}
		}

		function openPDF() {
			var base64Pdf = imagesScanned[0].src;
			// Create a data URI for the PDF
			var pdfDataUri = base64Pdf;
			// Open the PDF in a new tab
			var newTab = window.open();
			newTab.document.write('<embed width="100%" height="100%" src="' + pdfDataUri + '" type="application/pdf">');
			// Close the document to finalize it
			newTab.document.close();
		}
	</script>

	<style>
		img.scanned {
			height: 200px;
			/** Sets the display size */
			margin-right: 12px;
			border-radius: 15px;
			border: 2px solid #e1e1e1;
		}

		img.scanned:hover {
			height: 200px;
			/** Sets the display size */
			margin-right: 12px;
			border-radius: 15px;
			border: 5px solid #0069d9;
		}

		img.view {
			cursor: pointer;
		}

		div#images {
			margin-top: 10px;
		}
	</style>
</head>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">
				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Upload Documents</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<div class="body mt-4">
								<div class="card" style="border: 1px solid #e5e5e5; margin-top: -20px;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Document Upload Form
										</div>
									</div>
									<div class="card-body">
										<form id="document_upload_form" enctype="multipart/form-data">
											<div class="row">
												<label class="form-label col-md-3">Parent System<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="system" id="system" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select Parent System...</option>
														<?php
														foreach ($systems as $system) { ?>
															<option value="<?php echo $system['system_id']; ?>"><?php echo $system['system_name']; ?></option>
														<?php
														}
														?>
													</select>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Category<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="category" id="category" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Category...</option>
													</select>
												</div>
											</div>
											<input type="hidden" name="cat_name" id="cat_name">
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Registry<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="registry" id="registry" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Registry...</option>
													</select>
												</div>
											</div>
											<input type="hidden" name="registry_name" id="registry_name">
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Name<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="doc_name" id="doc_name" placeholder="Enter Document Name" required>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Description</label>
												<div class="col-md-9">
													<textarea name="description" id="description" cols="30" rows="10" class="form-control" style="height: 100px;" placeholder="Additional Notes ..."></textarea>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Path<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9 d-flex flex-column">
													<button type="button" class="btn btn-dark w-100" id="selectDocumentBtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Select a Document</button>
													<div class="mt-2 alert alert-warning">
														Document to Upload : <strong id="doc_to_upload">None</strong>
														<br>
														Document Type : <strong id="doc_to_upload_type">None</strong>
														<div id="remove_scanned_doc" class="d-none">
															<br>
															<div class="d-flex">
																<button id="view_scanned_doc_btn" type="button" class="btn btn-success me-2" style="font-size: 12px;"> <i class="bi bi-eye-fill"></i> View Scanned Document</button>
																<button id="remove_scanned_doc_btn" type="button" class="btn btn-danger" style="font-size: 12px;"> <i class="bi bi-x-circle-fill"></i> Remove Scanned Document</button>
															</div>
														</div>
													</div>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Location<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="location" id="location" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Location...</option>
														<?php
														foreach ($locations as $location) {
															echo '<option value="' . $location['id'] . '">' . $location['location_name'] . '</option>';
														}
														?>
													</select>
												</div>
												<input type="hidden" name="location_name" id="location_name">
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Cost Center<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="cost_center" id="cost_center" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Cost Center...</option>
													</select>
												</div>
												<input type="hidden" name="cost_center_name" id="cost_center_name">
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Employee Code<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="emp_code" id="emp_code" placeholder="Enter Employee Code" required>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-md-12 mt-2">
													<button type="submit" class="btn btn-primary float-right px-5"> <i class="bi bi-upload"></i>&nbsp;&nbsp;&nbsp;Upload</button>
												</div>
											</div>
										</form>
									</div>
								</div>
								<div class="card" id="scannedImagesCard" style="border: 1px solid #e5e5e5; margin-top: -20px; display: none;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Thumbnails of Scanned Pages
										</div>
									</div>
									<div class="card-body">
										<div id="images"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Choose Document Modal -->

		<div class="modal" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="staticBackdropLabel">Choose the Document to Upload</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<div class="d-flex flex-column text-center mt-3">
							<button type="button" onclick="scanToPdfWithThumbnails();" class="btn btn-success w-100 mb-2"><i class="bi bi-upc-scan"></i>&nbsp;&nbsp;&nbsp;Scan a Document</button>
							<small> -- or browse a document -- </small>
							<div class="input-group">
								<div class="custom-file">
									<input type="file" class="form-control w-100" accept=".pdf, .doc, .docx, .tiff, .jpg, .bmp, .pdf, .xls, .xlsx, .doc, .docx" id="fileInput">
									<!-- Hidden input store base64 PDF string -->
									<input type="hidden" name="base64_pdf" id="base64_pdf">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary px-4" data-bs-dismiss="modal">OK</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
	<script src="<?php echo base_url(); ?>assets/bundles/libscripts.bundle.js"></script>
	<script src="<?php echo base_url(); ?>assets/bundles/vendorscripts.bundle.js"></script>
	<script src="<?php echo base_url(); ?>assets/select2/select2.full.min.js"></script>

	<script src="<?php echo base_url(); ?>assets/bundles/easypiechart.bundle.js"></script> <!-- easypiechart Plugin Js -->

	<script src="<?php echo base_url(); ?>assets/bundles/mainscripts.bundle.js"></script>
	<script src="<?php echo base_url(); ?>assets/bundles/datatablescripts.bundle.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/pages/tables/jquery-datatable.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<script>
		$(document).ready(function() {

			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// clear scanned images
			$('#remove_scanned_doc_btn').click(function() {

				Swal.fire({
					title: 'Please Confirm',
					text: "Are you sure you want to remove this scanned document ?",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#d33',
					cancelButtonColor: '#3085d6',
					confirmButtonText: 'Yes, remove it!'
				}).then((result) => {
					if (result.isConfirmed) {
						imagesScanned = [];
						document_scanned_successfully = false;
						document.getElementById('images').innerHTML = ''; // clear images
						document.getElementById('scannedImagesCard').style.display = 'none';
						document.getElementById('doc_to_upload').innerHTML = 'None';
						document.getElementById('doc_to_upload_type').innerHTML = 'None';
						$('#remove_scanned_doc').addClass('d-none');
					}
				})
			});

			// view scanned images
			$('#view_scanned_doc_btn').click(function() {
				openPDF();
			});

			// fileInput on change event
			$('#fileInput').on('change', function() {
				const fileInput = document.getElementById('fileInput');

				// Check if a file is selected
				if (fileInput.files.length > 0) {

					// Get the selected file
					const selectedFile = fileInput.files[0];

					// Extract file name and format (extension)
					const fileName = selectedFile.name;
					const fileFormat = getFileFormat(fileName);

					// Check if the file format is allowed
					if (isAllowedFileFormat(fileFormat)) {
						// Display the extracted information
						if (document_scanned_successfully) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: 'There is a scanned document already in the queue. Only one document can upload at a time.  If you want to upload a browsed document, please remove the scanned document and try again!',
							});
							fileInput.value = null;
						} else {
							document.getElementById('doc_to_upload').innerHTML = fileName;
							document.getElementById('doc_to_upload_type').innerHTML = fileFormat.toUpperCase();
						}
					} else {
						// clear the selected file
						fileInput.value = null;
						if (!document_scanned_successfully) {
							document.getElementById('doc_to_upload').innerHTML = 'None';
							document.getElementById('doc_to_upload_type').innerHTML = 'None';
						}
						// Display error message swal
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Invalid file format! Please select a PDF, DOC or DOCX file.',
						});
					}

				} else {
					// Display error message swal
					fileInput.value = null;
					if (!document_scanned_successfully) {
						document.getElementById('doc_to_upload').innerHTML = 'None';
						document.getElementById('doc_to_upload_type').innerHTML = 'None';
					}
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'No file selected! Please select a file.',
					});
				}
			});

			// Function to get the file format (extension)
			function getFileFormat(fileName) {
				const dotIndex = fileName.lastIndexOf('.');
				if (dotIndex !== -1) {
					return fileName.substring(dotIndex + 1).toLowerCase();
				}
				return 'Unknown';
			}

			// Function to check if the file format is allowed
			function isAllowedFileFormat(fileFormat) {
				const allowedFormats = ['pdf', 'doc', 'docx', 'tiff', 'jpg', 'jpeg', 'bmp', 'xls', 'xlsx'];
				return allowedFormats.includes(fileFormat);
			}

			// system select on change event
			$('#system').on('change', function() {
				var system_id = $(this).val();
				var access_token;
				if (system_id != 0) {
					$.ajax({
						type: "GET",
						headers: {
							'Authorization': 'Bearer ' + access_token
						},
						url: "<?php echo base_url('documents/upload/get_system_categories'); ?>/" + system_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#category').html('<option value="0">Select a Category...</option>');
							$.each(response, function(index, value) {
								$('#category').append('<option value="' + value.id + '">' + value.category_name + '</option>');
							});
						}
					});
				}
			});

			// category select on change event
			$('#category').on('change', function() {
				var category_id = $(this).val();
				if (category_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('documents/upload/get_category_registries'); ?>/" + category_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#registry').html('<option value="0">Select a Registry...</option>');
							$.each(response, function(index, value) {
								$('#registry').append('<option value="' + value.id + '">' + value.registry_name + '</option>');
							});
						}
					});
				}
			});

			// location select on change event
			$('#location').on('change', function() {
				var location_id = $(this).val();
				if (location_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('documents/upload/get_cost_centers'); ?>/" + location_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
							$.each(response, function(index, value) {
								$('#cost_center').append('<option value="' + value.id + '">' + value.cost_center_name + '</option>');
							});
						}
					});
				}
			});

			// Document Upload Form Submit
			$('#document_upload_form').submit(function(e) {
				e.preventDefault();

				// get selected system id
				var system_id = $('#system').val();
				// get selected category id
				var category_id = $('#category').val();
				// get selected registry id
				var registry_id = $('#registry').val();
				// get file input
				var fileInput = document.getElementById('fileInput');

				if (system_id == 0 || category_id == 0 || registry_id == 0) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Please fill all the required fields!',
					});
				} else if (fileInput.files.length == 0 && $('#base64_pdf').val() == '') {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Please browse or scan a document!',
					});
				} else {
					UploadDocument();
				}
			});

			function UploadDocument() {

				// show loading modal
				$('#loadingModal').modal('show');

				// upload document
				var formData = new FormData($('#document_upload_form')[0]);
				// append base64_pdf to the FormData
				var base64 = $('#base64_pdf').val();
				formData.append('scanned_file', base64);
				// append file to the FormData
				formData.append('browsed_file', fileInput.files[0]);

				$.ajax({
					type: "POST",
					url: "<?php echo base_url(); ?>documents/upload/create",
					data: formData,
					processData: false,
					contentType: false,
					success: function(response) {
						var response = JSON.parse(response);
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
							}).then((result) => {
								if (result.isConfirmed) {
									location.reload();
								}
							});
						} else if (response.status == 400) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status == 500) {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
						// hide loading modal
						$('#loadingModal').modal('hide');
					},
					error: function(response) {
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: 'Something went wrong!',
						});
						// hide loading modal
						$('#loadingModal').modal('hide');
					},
				});
			}
		});
	</script>
</body>

</html>