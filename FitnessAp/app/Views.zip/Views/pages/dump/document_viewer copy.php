<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Just a moment...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">View Documents</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<!-- <div class="header">
								<h2>Document Forwarding Setup</h2>
							</div> -->

							<div class="body mt-2">
								<?php if ($document == null) {
									if ($message != "") {
										echo '<div class="alert alert-danger" role="alert">' . $message . '</div>';
									} else {
								?>
										<div class="d-flex flex-column text-center">
											<div class="alert alert-danger" role="alert">
												<h6>Please select a document to view and come back.</h6><a href="<?php echo base_url(); ?>documents/browse" class="mt-2 btn btn-danger px-4" style="width: fit-content">Browse Documents</a>
											</div>
										</div>;

									<?php
									}
									?>
								<?php } else { ?>
									<div class="card" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Document View & Other Actions
											</div>
										</div>

										<div class="card-body">
											<div class="row">
												<div class="col-lg-12 col-sm-12">
													<div class="row">
														<div class="col-lg-6 col-sm-12">
															<div class="img-thumbnail h-100 d-flex justify-content-center align-items-center">
																<?php
																$url = "";
																$base_url = base_url() . "assets/images/formats";
																switch ($document['type']) {
																	case "pdf":
																		$url = $base_url . "/pdf.png";
																		break;
																	case "doc":
																		$url = $base_url . "/docx.png";
																		break;
																	case "docx":
																		$url = $base_url . "/docx.png";
																		break;
																	case "xls":
																		$url = $base_url . "/xls.png";
																		break;
																	case "xlsx":
																		$url = $base_url . "/xls.png";
																		break;
																	case "csv":
																		$url = $base_url . "/xls.png";
																		break;
																	case "jpg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "jpeg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "png":
																		$url = $base_url . "/png.png";
																		break;
																	case "bmp":
																		$url = $base_url . "/bmp.png";
																		break;
																	case "tiff":
																		$url = $base_url . "/tiff.png";
																		break;
																	case "tif":
																		$url = $base_url . "/tiff.png";
																		break;
																}
																?>
																<img src="<?php echo $url; ?>" alt="placeholder" width="50%" class="img-fluid">
															</div>
														</div>
														<div class="col-lg-6 col-sm-12">
															<div class="d-flex flex-column">
																<div class="d-flex flex-column" id="doc-info">
																	<div class="d-flex">
																		<div class="me-auto">
																			<h6 class="text-primary mb-3"><strong>Document Details</strong></h6>
																		</div>
																		<div>
																			<!-- <button class="btn btn-light"><i class="bi bi-three-dots-vertical"></i> More Details</button> -->
																		</div>
																	</div>
																	<div class="form-group d-flex flex-column">
																		<span>Document Name</span>
																		<label><strong><?php echo $document['name'] . "   (" . strtoupper($document['type']) . ")"; ?></strong></label>
																	</div>
																	<div class="form-group d-flex flex-column" style="margin-top: -15px;">
																		<span>Uploaded At</span>
																		<label><strong><?php echo $document['uploaded_at']; ?></strong></label>
																	</div>
																</div>
																<div class="d-flex flex-column" style="margin-top: -10px;">
																	<button class="btn btn-light" data-bs-toggle="modal" data-bs-target="#exampleModal" style="width: fit-content;"><i class="bi bi-three-dots-vertical"></i> More Details</button>
																	<div class="btn-group mt-2" role="group" aria-label="Basic example">
																		<button id="download_btn" data-document-type="<?php echo $document['type']; ?>" data-document-id="<?php echo $document['document_id']; ?>" type="button" class="btn btn-dark"><i class="bi bi-download"></i>&nbsp;&nbsp;&nbsp;Download</button>
																		<button id="open_btn" type="button" data-document-id="<?php echo $document['document_id']; ?>" data-document-type="<?php echo $document['type']; ?>" class="btn btn-dark px-3"><i class="bi bi-box-arrow-up-right"></i>&nbsp;&nbsp;&nbsp;Open</button>
																		<button id="print_btn" type="button" data-document-id="<?php echo $document['document_id']; ?>" data-document-type="<?php echo $document['type']; ?>" class="btn btn-dark px-3"><i class="bi bi-printer"></i>&nbsp;&nbsp;&nbsp;Print</button>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="row mt-3">
												<div class="col-12">
													<ul class="nav nav-tabs" id="myTab" role="tablist">
														<li class="nav-item" role="presentation">
															<button class="nav-link active" id="timeline-tab" data-bs-toggle="tab" data-bs-target="#timeline-tab-pane" type="button" role="tab" aria-controls="timeline-tab-pane" aria-selected="true">Changes Timeline</button>
														</li>
														<li class="nav-item" role="presentation">
															<button class="nav-link" id="comments-tab" data-bs-toggle="tab" data-bs-target="#comments-tab-pane" type="button" role="tab" aria-controls="comments-tab-pane" aria-selected="false">Comments</button>
														</li>
													</ul>
													<div class="tab-content" id="myTabContent">
														<div class="tab-pane fade show active" id="timeline-tab-pane" role="tabpanel" aria-labelledby="timeline-tab" tabindex="0">
															<ol class="timeline">
																<li class="timeline-item">
																	<span class="timeline-item-icon | faded-icon">
																		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
																			<path fill="none" d="M0 0h24v24H0z" />
																			<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />
																		</svg>
																	</span>
																	<div class="timeline-item-description">
																		<i class="avatar | small">
																			<img src="https://assets.codepen.io/285131/winking-girl.png" />
																		</i>
																		<div class="d-flex flex-column">
																			<div>
																				<span><a href="#">Hasintha Nayanajith </a>uploaded the document.</span>
																			</div>
																			<div>
																				<small>2023-12-10 at 10:32 AM</small>
																			</div>
																		</div>
																	</div>
																</li>
															</ol>
														</div>
														<div class="tab-pane fade" id="comments-tab-pane" role="tabpanel" aria-labelledby="comments-tab" tabindex="0">
															<ol class="timeline">
																<li class="timeline-item">
																	<span class="timeline-item-icon | avatar-icon">
																		<i class="avatar">
																			<img src="https://assets.codepen.io/285131/hat-man.png" />
																		</i>
																	</span>
																	<div class="d-flex w-100 border rounded p-1">
																		<style>
																			.comment-bx {
																				border: none;
																				outline: none;
																			}

																			.comment-bx:focus {
																				border: none;
																				outline: none;
																				box-shadow: none;
																			}
																		</style>
																		<input class="comment-bx m-1 w-100" placeholder="Add a comment..." />
																		<button class="btn btn-dark"><i class="bi bi-send-fill"></i></button>
																	</div>
																</li>
																<li class="timeline-item">
																	<span class="timeline-item-icon | faded-icon">
																		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
																			<path fill="none" d="M0 0h24v24H0z" />
																			<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />
																		</svg>
																	</span>
																	<div class="timeline-item-description">
																		<i class="avatar | small">
																			<img src="https://assets.codepen.io/285131/winking-girl.png" />
																		</i>
																		<div class="d-flex flex-column">
																			<div>
																				<span><a href="#">Hasintha Nayanajith </a>uploaded the document.</span>
																			</div>
																			<div>
																				<small>2023-12-10 at 10:32 AM</small>
																			</div>
																		</div>
																	</div>
																</li>
															</ol>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- more details -->
		<div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="exampleModalLabel">Document Details</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body p-4">
						<div class="row">
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Parent System</span>
									<label class="form-label text-dark"><?php echo $document['system_name']; ?></label>
								</div>
							</div>
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Category Name</span>
									<label class="form-label text-dark"><?php echo $document['category_name']; ?></label>
								</div>
							</div>
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Registry Name</span>
									<label class="form-label text-dark"><?php echo $document['registry_name']; ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Location Name</span>
									<label class="form-label text-dark"><?php echo $document['location_name']; ?></label>
								</div>
							</div>
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Cost Center Name</span>
									<label class="form-label text-dark"><?php echo $document['cost_center_name']; ?></label>
								</div>
							</div>
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Employee Code</span>
									<label class="form-label text-dark"><?php echo $document['employee_code']; ?></label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12 d-flex flex-column">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Document Name</span>
									<label class="form-label text-dark"><?php echo $document['name'] . "   (" . strtoupper($document['type']) . ")"; ?></label>
								</div>
							</div>
							<div class="col-6"></div>
						</div>
						<div class="row">
							<div class="col-12 d-flex flex-column">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Description</span>
									<p class="form-label text-dark"><?php echo $document['description']; ?></p>
								</div>
							</div>
							<div class="col-6"></div>
						</div>
						<div class="row">
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Uploaded By [System]</span>
									<label class="form-label text-dark"><?php echo $document['uploaded_by']; ?></label>
								</div>
							</div>
							<div class="col-4">
								<div class="form-group d-flex flex-column">
									<span style="font-weight: 400;">Uploaded At</span>
									<label class="form-label text-dark"><?php echo $document['uploaded_at']; ?></label>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary px-3" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>
	<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.269/pdf.min.mjs"></script> -->

	<script>
		$(document).ready(function() {
			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// open_btn click event
			$('#open_btn').click(function() {
				var document_id = $(this).attr('data-document-id');
				var document_type = $(this).attr('data-document-type');

				if (document_type == 'pdf' || document_type == 'png' || document_type == 'jpeg' || document_type == 'jpg') {
					// file can be opened in a new tab
					var url = '<?= base_url(); ?>/documents/view/get_document_content/' + document_id;
					var win = window.open(url, '_blank');

				} else if (document_type == 'doc' || document_type == 'docx') {
					// get file content using ajax
					$.ajax({
						url: '<?= base_url(); ?>/documents/view/get_document_content/' + document_id,
						type: 'GET',
						success: function(response) {
							// open docx_viewer
							var temp_file_name = new Date().getTime().toString() + '.docx';
							// Convert blobData to a FormData object
							var formData = new FormData();
							formData.append('file', response, temp_file_name); 

							// Create a new XMLHttpRequest object
							var xhr = new XMLHttpRequest();

							// Set up the request
							xhr.open('POST', '<?= base_url(); ?>documents/view/docx_viewer', true);

							// Define the onload event handler
							xhr.onload = function() {
								if (xhr.status === 200) {
									// Open the view in a new tab
									var newTab = window.open(baseUrl + '/documents/view/docx_viewer', '_blank');
								} else {
									alert('Error loading the view:', xhr.status, xhr.statusText);
								}
							};

							// Send the FormData with the blob content
							xhr.send(formData);
						},
						error: function(xhr, ajaxOptions, thrownError) {
							alert(xhr.status);
							console.log(xhr.status);
							console.log(thrownError);
						}
					});
				} else {
					// file can be opened in a new tab
					Swal.fire({
						icon: 'warning',
						title: 'Cannot Open.',
						text: 'Sorry, this document type is not supported for preview. Please download and open it.',
					});
				}
			});

		});
	</script>
</body>

</html>