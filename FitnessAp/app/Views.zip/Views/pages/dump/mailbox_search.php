<!doctype html>
<html lang="en">

<head>
	<title>:: EDMS ::</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
	<meta name="author" content="WrapTheme, design by: ThemeMakker.com">

	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<!-- VENDOR CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/sweetalert/sweetalert.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/color_skins.css">

	<style>
		.debug {
			border: 1px solid red;
		}
	</style>

</head>

<body class="theme-cyan">

<!-- Page Loader -->
<div class="page-loader-wrapper">
	<div class="loader">
		<div class="m-t-30"><img src="http://www.wrraptheme.com/templates/lucid/hospital/assets/images/logo-icon.svg" width="48" height="48" alt="Lucid"></div>
		<p>Please wait...</p>
	</div>
</div>
<!-- Overlay For Sidebars -->

<div id="wrapper">

	<?php
	echo $nav_bar;
	echo $side_bar;
	?>

	<div id="main-content">
		<div class="container-fluid">

			<!-- <?php echo $block_header; ?> -->

			<div class="row mt-4">
				<div class="col-md-10 d-flex">
					<h4 class="p-title">Search Assignment Details</h4>
				</div>
			</div>

			<div class="row clearfix mt-3">
				<div class="col-md-12">
					<div class="card">
						<div class="header">
							<h2>Search</h2>
						</div>

						<div class="body">
							<form id="compose_form" style="margin-bottom: 75px;">

								<label class="form-label col">Type<span
										style="color: #FF0000; "><strong>*</strong></span></label>
								<div class="col-md-10">
									<select name="type" id="type" class="js-example-basic-single form-control"
											style="width: 100%;" required="">
										<option value="0">Select letter type...</option>
										<option value="1">category1</option>
									</select>
								</div>
								<br>

								<label class="form-label col">Category<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<select name="category" id="category" class="js-example-basic-single form-control"
											style="width: 100%;" required="">
										<option value="0">Select a Registry...</option>
									</select>
								</div>
								<br>

								<label class="col">To<font color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="email" class="form-control" name="to" id="to"
										   placeholder="Mail To..." required="">
								</div>
								<br>

								<label class="col">From<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="email" class="form-control" name="from" id="from"
										   placeholder="Mail From..." required="">
								</div>
								<br>

								<label class="col">Reference No<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="ref-no" id="ref-no"
										   placeholder="Reference No..." required="">
								</div>
								<br>

								<label class="col">Stamp Date<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="date" class="form-control" name="stamp-date" id="stamp-date"
										   placeholder="Stamp Date..." required="">
								</div>
								<br>

								<label class="col">Letter Date<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="date" class="form-control" name="letter-date" id="letter-date"
										   placeholder="Letter Date..." required="">
								</div>
								<br>

								<label class="col">Heading<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="heading" id="heading"
										   placeholder="Mail Heading..." required="">
								</div>
								<br>

								<label class="col">Signed by<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<input type="text" class="form-control" name="signed_by" id="signed_by"
										   placeholder="Mail Signed by..." required="">
								</div>
								<br>

								<label class="col">Letter Content<font
										color="#FF0000"><strong>*</strong></font></label>
								<div class="col-md-10">
									<textarea class="form-control" name="content" id="content"
										   placeholder="" required=""></textarea>
								</div>
								<br>

								<div class="row">
									<div class="col-md-12 mt-3">
										<button type="submit" class="btn btn-primary float-left px-5 ml-2">Search</button>
									</div>
								</div>

							</form>


						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- menu_item Edit offcanvas -->

</div>

<!-- Javascript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="<?php echo base_url(); ?>assets/bundles/libscripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/bundles/vendorscripts.bundle.js"></script>

<script src="<?php echo base_url(); ?>assets/bundles/easypiechart.bundle.js"></script> <!-- easypiechart Plugin Js -->

<script src="<?php echo base_url(); ?>assets/bundles/mainscripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/bundles/datatablescripts.bundle.js"></script>
<script src="<?php echo base_url(); ?>assets/js/pages/tables/jquery-datatable.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

	$(document).ready(function(){

		// show forward form
		$('#btn_advance_search').click(function(){
			$('#form-advance-search').removeClass('d-none');
			// $('#doc-info').addClass('d-none');
		});

	} );

</script>
</body>

</html>

