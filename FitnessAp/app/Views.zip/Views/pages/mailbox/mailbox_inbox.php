<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<div class="row mt-4">
					<div class="col-md-12 d-flex">
						<div class="me-auto">
							<h4 class="p-title">Inbox</h4>
						</div>
						<div class="d-flex justify-content-end align-items-center">
							<button type="button" class="btn btn-danger" data-bs-toggle="offcanvas" data-bs-target="#composeOffcanvas">
								<i class="bi bi-pen-fill"></i> Compose
							</button>
						</div>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">

							<div class="body">

								<div class="card" style="border: 1px solid #e5e5e5;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Search Assignment Details
										</div>
									</div>
									<div class="body">
										<div class="table-responsive">
											<table class="table js-basic-example dataTable table-custom table-hover">
												<thead class="thead-light">
													<tr>
														<th style="width: 5px;">Type</th>
														<th>From</th>
														<th style="width: 50%;">Heading</th>
														<th>Date</th>
														<th style="width: 5px;">Actions</th>
													</tr>
												</thead>
												<tbody>
													<?php
													$x = 1;
													if (isset($inbox_data)) {
														foreach ($inbox_data as $inbox) {
															$forwarded_date = date_format(date_create($inbox['forwarded_at']), 'Y-m-d');
															$forwarded_time = date_format(date_create($inbox['forwarded_at']), 'h:i A');
															$type = base_url() . 'assets/images/status/';
															if ($inbox['is_a_document'] == 1) $type .= 'arrow.png';
															else $type .= 'email.png';
													?>
															<tr id="doc_row" class="doc_row" value="<?php echo $inbox['document_id']; ?>">
																<td class="inbox_td" data-is-document="<?php echo $inbox['is_a_document']; ?>" data-forward-id="<?php echo $inbox['id']; ?>" data-document-id="<?php echo $inbox['document_id']; ?>">
																	<div class="d-flex justify-content-center">
																		<img src="<?php echo $type; ?>" width="20px" alt="type">
																	</div>
																</td>
																<td><a data-forwarded-by="<?php echo $inbox['forwarded_by']; ?>" class="text-info emp_details" href="#"><?php echo $inbox['forwarded_by_name']; ?></a></td>
																<td class="inbox_td" data-is-document="<?php echo $inbox['is_a_document']; ?>" data-forward-id="<?php echo $inbox['id']; ?>" data-document-id="<?php echo $inbox['document_id']; ?>">
																	<p style="text-wrap: wrap;"><?php echo $inbox['document_name']; ?></p>
																</td>
																<td class="inbox_td" data-is-document="<?php echo $inbox['is_a_document']; ?>" data-forward-id="<?php echo $inbox['id']; ?>" data-document-id="<?php echo $inbox['document_id']; ?>"><?php echo $forwarded_date; ?><br><?php echo $forwarded_time; ?></td>
																<td>
																	<div class="d-flex justify-content-center">
																		<button type="button" class="btn btn-primary btn-sm me-1 more_info" data-is-document="<?php echo $inbox['is_a_document']; ?>" data-forward-id="<?php echo $inbox['id']; ?>" data-document-id="<?php echo $inbox['document_id']; ?>" data-toggle="tooltip" data-placement="top" title="More Info">
																			<i class="bi bi-eye-fill"></i>
																		</button>
																		<button type="button" class="btn btn-warning btn-sm me-1 doc_forward" data-is-document="<?php echo $inbox['is_a_document']; ?>" data-forward-id="<?php echo $inbox['id']; ?>" data-document-id="<?php echo $inbox['document_id']; ?>" id="doc_forward" data-toggle="tooltip" data-placement="top" title="Forward">
																			<i class="bi bi-arrow-right-circle-fill"></i>
																		</button>
																		<span class="d-inline-block finalize_btn_span" data-forward-id="<?php echo $inbox['id']; ?>" tabindex="0" data-toggle="tooltip" data-placement="top" title="<?php echo ($inbox['is_finalized'] == 1) ? "Already Finalized" : "Mark as Finalized" ?>">
																			<button data-forward-id="<?php echo $inbox['id']; ?>" type="button" class="btn btn-success btn-sm finalize_btn" <?php echo ($inbox['is_finalized'] == 1) ? "disabled" : "" ?>>
																				<i class="bi bi-check-circle-fill"></i>
																			</button>
																		</span>
																	</div>
																</td>
															</tr>
													<?php
															$x++;
														}
													}
													?>
												</tbody>
											</table>
										</div>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Compose offcanvas -->
		<div class="offcanvas offcanvas-end" style="width: 75%;" id="composeOffcanvas" aria-labelledby="composeOffcanvasLabel">
			<div class="offcanvas-header">
				<h5 id="composeOffcanvasLabel">New Message</h5>
				<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body">
				<div class="">
					<div class="">
						<form id="compose-form">
							<div class="row">
								<div class="col-4">
									<div class="form-group">
										<label for="">Select a Location</label>
										<select name="location" id="location" class="js-example-basic-single form-control" aria-label=".form-select-sm example">
											<option value="0">Select a Location...</option>
											<?php
											foreach ($locations as $location) {
												echo '<option value="' . $location['id'] . '">' . $location['location_name'] . '</option>';
											}
											?>
										</select>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group">
										<label for="">Select a Cost Center</label>
										<select name="cost_center" id="cost_center" class="js-example-basic-single form-control" aria-label=".form-select-sm example">
											<option value="0">Select a Cost Center...</option>
										</select>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group">
										<label for="">Select a Designation</label>
										<select name="designation" id="designation" class="js-example-basic-single form-control" aria-label=".form-select-sm example">
											<option value="0">Select a Designation...</option>
											<?php
											if (isset($designations)) {
												foreach ($designations as $designation) {
													echo '<option value="' . $designation['designation_name'] . '">' . $designation['designation_name'] . '</option>';
												}
											}
											?>
										</select>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label for="">Select a Employee</label>
								<select name="employee" id="employee" class="js-example-basic-single form-control" aria-label=".form-select-sm example">
									<option value="0">Select a Employee...</option>
								</select>
							</div>

							<div class="form-check">
								<input id="is_finalized" class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
								<label class="form-check-label text-info" for="flexCheckChecked">
									Mark as Finalized
								</label>
							</div>
							<hr>
							<div class="form-group">
								<label for="">Subject</label>
								<input type="text" class="form-control" name="subject" id="subject">
							</div>
							<div class="form-group">
								<label for="formFile" class="form-label"><i class="bi bi-paperclip"></i>&nbsp; Attachments</label>
								<input class="form-control" type="file" id="formFile" name="attachments[]" multiple>
							</div>
							<div class="form-group">
								<label for="">Body</label>
								<div class="summernote h-auto" id="summernote">
								</div>
							</div>
						</form>
						<div class="m-t-30">
							<button type="button" class="btn btn-success send" id="send">Send Message</button>
							<!-- <button type="button" class="btn btn-secondary">Draft</button> -->
							<button data-bs-dismiss="offcanvas" aria-label="Close" class="btn btn-outline-secondary">Cancel</button>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Messages More Info Modal -->
		<div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" id="messageInfoModal" tabindex="-1" role="dialog" aria-labelledby="messageInfoModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="messageInfoModalLabel">Message Details</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<style>
							#messageInfoModal .form-group span {
								font-weight: 700;
								color: #000;
							}
						</style>
						<div class="form-group d-flex flex-column">
							<label>From</label>
							<span id="mi_from"></span>
						</div>
						<div class="form-group d-flex flex-column">
							<label>To</label>
							<span id="mi_employee"></span>
							<span id="mi_designation"></span>
							<span id="mi_cost_center"></span>
							<span id="mi_location"></span>
						</div>
						<div class="form-group d-flex flex-column mt-2">
							<label>Subject</label>
							<span style="color: dodgerblue; font-size: 16px;" id="mi_subject"></span>
						</div>
						<div class="form-group d-flex flex-column mt-2">
							<label>Attachments</label>
							<div id="mi_attachments" class="d-flex flex-wrap">
							</div>
						</div>
						<div class="form-group d-flex flex-column mt-2">
							<label>Message</label>
							<div id="mi_body" class="p-3" style="border-radius: 10px; background-color: #f3f3f9;"></div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Employee Info Modal -->
		<div class="modal fade" data-bs-keyboard="false" id="empDetailsModal" tabindex="-1" role="dialog" aria-labelledby="empDetailsModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="empDetailsModalLabel">Sender Details</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="d-flex flex-column justify-content-center align-items-center">
							<img src="<?php echo base_url() ?>assets/images/employees/user.png" width="100px" alt="user" style="border-radius: 50px; margin-bottom: 20px">
							<h6><strong id="emp_d_name"></strong></h6>
							<span id="emp_d_designation"></span>
							<span id="emp_d_cost_center"></span>
							<span id="emp_d_location"></span>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Forward Comment Modal -->
		<div class="modal fade" data-bs-keyboard="false" id="forwardCommentModal" tabindex="-1" role="dialog" aria-labelledby="empDetailsModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="empDetailsModalLabel">Forward Details</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="d-flex flex-column text-start">
							<h6 class="text-info"><strong>Comments</strong></h6>
							<p id="forward_comment"></p>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>
	<script src="<?php echo base_url(); ?>assets/vendor/summernote/dist/summernote.js"></script>

	<script>
		$(document).ready(function() {

			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			$('#summernote').summernote({
				height: 300,
				toolbar: [
					['style', ['style']],
					['font', ['bold', 'italic', 'underline', 'clear']],
					['para', ['ul', 'ol', 'paragraph']],
					['height', ['height']],
					['insert', ['link']],
					['view', ['fullscreen', 'codeview']],
					['link', ['linkDialogShow', 'unlink']],
					['color', ['color']],
					['table', ['table']]
				],
				buttons: {
					picture: false,
					video: false
				}
			});

			// location select on change event
			$('#location').on('change', function() {
				// #cost_center, #designation, #employee select options reset
				$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
				$('#designation').html('<option value="0">Select a Designation...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#cost_center').trigger('change');
				$('#designation').trigger('change');
				$('#employee').trigger('change');
				// get location_id
				var location_id = $(this).val();
				if (location_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_cost_centers'); ?>/" + location_id,
						dataType: "json",
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
							$.each(response, function(index, value) {
								$('#cost_center').append('<option value="' + value.cost_center_id + '">' + value.cost_center_name + '</option>');
							});
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				} else {
					ResetDesignations();
				}
			});
			// cost_center select on change event
			$('#cost_center').on('change', function() {
				// #designation, #employee select options reset
				$('#designation').html('<option value="0">Select a Designation...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#designation').trigger('change');
				$('#employee').trigger('change');
				// get cost_center_id
				var cost_center_id = $(this).val();
				if (cost_center_id != 0) {
					$.ajax({
						type: "POST",
						url: "<?php echo base_url('data/get_designations_from_employees'); ?>",
						dataType: "json",
						data: {
							'location': $('#location option:selected').text(),
							'cost_center': $('#cost_center option:selected').text()
						},
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							$('#designation').html('<option value="0">Select a Designation...</option>');
							$.each(response, function(index, value) {
								$('#designation').append('<option value="' + value.designation + '">' + value.designation + '</option>');
							});
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
			});

			// designation select on change event
			$('#designation').on('change', function() {
				// #employee select options reset
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#employee').trigger('change');
				// if both location and cost_center are selected
				if ($('#location').val() != 0 && $('#cost_center').val() != 0) {
					// get designation_id
					var designation_id = $('#designation option:selected').text();
					if (designation_id != 'Select a Designation...') {
						$.ajax({
							type: "POST",
							url: "<?php echo base_url('data/get_employees'); ?>",
							data: {
								'location': $('#location option:selected').text(),
								'cost_center': $('#cost_center option:selected').text(),
								'designation': designation_id
							},
							dataType: "json",
							success: function(response) {
								// console.log(response);
								$('#employee').html('<option value="0">Select a Employee..</option>');
								$.each(response, function(index, value) {
									$('#employee').append('<option value="' + value.emp_code + '">' + value.name + " - " + value.designation + '</option>');
								});
							}
						});
					}
				}
			});

			function ResetDesignations() {
				$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#cost_center').trigger('change');
				$('#employee').trigger('change');

				$.ajax({
					type: "GET",
					url: "<?php echo base_url('data/get_designations'); ?>",
					dataType: "json",
					success: function(response) {
						$('#designation').html('<option value="0">Select a Designation...</option>');
						$.each(response, function(index, value) {
							$('#designation').append('<option value="' + value.designation_name + '">' + value.designation_name + '</option>');
						});
					}
				});
			}

			$('.table').on('click', '.doc_forward', function() {

				var is_document = $(this).attr('data-is-document');
				if (is_document == 1) {
					// open document forward page in a new tab
					var document_id = $(this).attr('data-document-id');
					window.open('<?php echo base_url() ?>documents/forward/' + document_id, '_blank');
				} else {

					// get forward id
					var forward_id = $(this).attr('data-forward-id');
					// get forward details
					$.ajax({
						url: '<?php echo base_url("documents/forward/get_forward_details") ?>/' + forward_id,
						type: 'get',
						dataType: 'json',
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(data) {
							$('#loadingModal').modal('hide');
							if (data.status == 200) {
								// set data to offcanvas summernote div and show offcanvas
								$('#summernote').summernote('code', data.data.comment);
								$('#subject').val(data.data.document_name);
								$('#composeOffcanvas').offcanvas('show');
							} else {
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: 'Something went wrong! Please try again later.',
								});
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
			});

			$(".send").click(function() {
				// get data from form including selected files from input type file
				var formData = new FormData($('#compose-form')[0]);
				// append summernote data to form data
				var summernoteContent = $('#summernote').summernote('code');
				formData.append('body', summernoteContent);
				// append is_finalized value to form data
				if ($('#is_finalized').is(':checked')) {
					formData.append('is_finalized', 1);
				} else {
					formData.append('is_finalized', 0);
				}
				// ajax
				$.ajax({
					url: '<?php echo site_url("mailbox/inbox/compose") ?>',
					type: 'post',
					data: formData,
					dataType: 'json',
					processData: false,
					contentType: false,
					beforeSend: function() {
						$('#send').html('<i class="bi bi-arrow-clockwise fa-spin"></i> Sending...');
					},
					success: function(data) {
						if (data.status == 201) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: data.message,
							}).then((result) => {
								if (result.isConfirmed) {
									window.location.href = "<?php echo base_url() ?>mailbox/inbox";
								}
							});
						} else if (data.status > 201 && data.status < 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: data.message ? data.message : 'Something went wrong! Please try again later.',
							});
						} else if (data.status == 500) {
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: data.message ? data.message : 'Something went wrong! Please try again later.',
							}).then((result) => {
								if (result.isConfirmed) {
									var upload_fails = data.upload_fails;
									if (upload_fails.length > 0) {
										var upload_fails_str = "";
										$.each(upload_fails, function(index, value) {
											upload_fails_str += value + "\n";
										});
										Swal.fire({
											icon: 'warning',
											title: 'Attachments Upload Failed.',
											text: upload_fails_str,
										});
									}
								}
							});
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					},
					complete: function() {
						$('#send').html('Send Message');
					}
				});
			});

			// table row click, trigger more info button click event
			$('.table').on('click', '.inbox_td', function() {
				var forward_id = $(this).attr('data-forward-id');
				var document_id = $(this).attr('data-document-id');
				var is_document = $(this).attr('data-is-document');
				see_document(is_document, forward_id, document_id, true);
			});

			function see_document(is_document, forward_id, document_id, is_row_click) {
				// get forward id
				var forward_id = forward_id;
				var document_id = document_id;

				// mark as seen
				$.ajax({
					url: '<?php echo base_url("mailbox/inbox/seen") ?>',
					type: 'post',
					data: {
						'forward_id': forward_id,
						'document_id': document_id
					},
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
					},
					success: function(data) {
						$('#loadingModal').modal('hide');
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					}
				});

				var is_document = is_document;
				if (is_document == 1) {
					if (!is_row_click) {
						// clear modal data
						$('#forward_comment').text('');

						// get forward details
						$.ajax({
							url: '<?php echo base_url("documents/forward/get_forward_details") ?>/' + forward_id,
							type: 'get',
							dataType: 'json',
							beforeSend: function() {
								$('#loadingModal').modal('show');
							},
							success: function(data) {
								$('#loadingModal').modal('hide');
								if (data.status == 200) {
									// set data to modal
									var comments = data.data.comment;
									if (comments == null || comments == "") comments = 'No comments';
									$('#forward_comment').text(comments);
									$('#forwardCommentModal').modal('show');
								} else {
									Swal.fire({
										icon: 'error',
										title: 'Oops...',
										text: 'Something went wrong! Please try again later.',
									});
								}
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('#loadingModal').modal('hide');
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: 'Something went wrong! Please try again later.',
								});
							}
						});
					} else {
						// open document view page in a new tab
						window.open('<?php echo base_url() ?>documents/view/' + document_id, '_blank');
					}
				} else {
					// clear modal data
					$('#mi_from').text('');
					$('#mi_employee').text('');
					$('#mi_designation').text('');
					$('#mi_cost_center').text('');
					$('#mi_location').text('');
					$('#mi_subject').text('');
					$('#mi_body').html('');

					// get forward details
					$.ajax({
						url: '<?php echo base_url("documents/forward/get_forward_details") ?>/' + forward_id,
						type: 'get',
						dataType: 'json',
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(data) {
							$('#loadingModal').modal('hide');
							if (data.status == 200) {
								// set data to modal
								$('#mi_from').text(data.data.forwarded_by_name);
								if (data.data.emp_name != null) $('#mi_employee').text(data.data.emp_name);
								if (data.data.designation_name != null) $('#mi_designation').text(data.data.designation_name);
								if (data.data.cost_center_name != null) $('#mi_cost_center').text(data.data.cost_center_name);
								if (data.data.location_name != null) $('#mi_location').text(data.data.location_name);
								$('#mi_subject').text(data.data.document_name);
								// populate attachments
								var attachments = data.data.attachments;
								if (attachments.length > 0) {
									var attachments_str = "";
									$.each(attachments, function(index, value) {
										attachments_str += '<div class="alert alert-primary me-1 mb-1" style="padding: 5px 15px;" ><a href="<?php echo base_url() ?>mailbox/inbox/download_attachment/' + value.id + '" class="text-dark" style="font-size: 12px;"><i class="bi bi-file-earmark-fill"></i> ' + value.attachment + '.' + value.file_ext + '</a></div>';
									});
									$('#mi_attachments').html(attachments_str);
								} else {
									$('#mi_attachments').html('<span class="text-muted">No attachments.</span>');
								}
								$('#mi_body').html(data.data.comment);
								$('#messageInfoModal').modal('show');
							} else {
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: 'Something went wrong! Please try again later.',
								});
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
			}

			// more info button click event
			$('.table').on('click', '.more_info', function() {
				var forward_id = $(this).attr('data-forward-id');
				var document_id = $(this).attr('data-document-id');
				var is_document = $(this).attr('data-is-document');
				see_document(is_document, forward_id, document_id, false);
			});

			// employee details button click event
			$('.table').on('click', '.emp_details', function() {
				// clear modal data
				$('#emp_d_name').text('');
				$('#emp_d_designation').text('');
				$('#emp_d_cost_center').text('');
				$('#emp_d_location').text('');
				// get emp_code
				var emp_code = $(this).attr('data-forwarded-by');
				// get employee details
				$.ajax({
					url: '<?php echo base_url("data/get_employee_by_code") ?>/' + emp_code,
					type: 'get',
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
					},
					success: function(data) {
						$('#loadingModal').modal('hide');
						// set data to modal
						$('#emp_d_name').text(data[0].name);
						$('#emp_d_designation').text(data[0].designation);
						$('#emp_d_cost_center').text(data[0].cost_center);
						$('#emp_d_location').text(data[0].location);
						$('#empDetailsModal').modal('show');
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					}
				});
			});

			// finalize_btn click event
			$('.table').on('click', '.finalize_btn', function() {
				// get forward id
				var forward_id = $(this).attr('data-forward-id');
				// get forward details
				$.ajax({
					url: '<?php echo base_url("mailbox/inbox/finalize_forward") ?>',
					type: 'post',
					data: {
						'forward_id': forward_id,
						'is_finalized': 1
					},
					dataType: 'json',
					beforeSend: function() {
						$('#loadingModal').modal('show');
					},
					success: function(data) {
						$('#loadingModal').modal('hide');
						if (data.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: data.message,
							}).then((result) => {
								if (result.isConfirmed) {
									window.location.href = "<?php echo base_url() ?>mailbox/inbox";
								}
							});
						} else {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: data.message ? data.message : 'Something went wrong! Please try again later.',
							});
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					}
				});
			});

		});
	</script>

</body>

</html>