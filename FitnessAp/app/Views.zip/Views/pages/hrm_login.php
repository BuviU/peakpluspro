<?= view('layouts/header'); ?>

<body class="theme-cyan" style="min-height: 100vh; background: rgb(255,255,255); background: linear-gradient(180deg, rgba(255,255,255,1) 35%, rgba(228,228,228,1) 100%);">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

    <div id="wrapper">
        <div>
            <div class="container-fluid pt-5">
                <div class="row clearfix pt-">
                    <div class="col-lg-4 offset-lg-4 col-md-4 offset-md-4 col-sm-8 offset-sm-2 pt-5">
                        <div class="card shadow">
                            <form id="login_form">
                                <div class="header text-center">
                                    <h2 style="font-size: 30px; font-weight: 800;">Sign In<small class="mt-2">First thing is first. Please log into continue.</small></h2>
                                </div>
                                <div class="body">
                                    <div class="row clearfix">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row clearfix">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row clearfix">
                                        <div class="col-sm-12 text-center">
                                            <button id="login_btn" type="submit" class="btn btn-primary w-100">Sign Me In</button>
                                            <div class="mt-3 login-sub-text">
                                                <style>
                                                    .login-sub-text span {
                                                        font-size: 12px;
                                                        font-weight: 600;
                                                    }
                                                </style>
                                                <span>Are you an Administrator ?&nbsp;&nbsp;&nbsp;</span><a href="<?php echo base_url('admin') ?>"><span>Login here !</span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?= view('layouts/footer'); ?>

    <script>
        $(document).ready(function() {
            // Login form submit
            $("#login_form").on('submit', (function(e) {
                e.preventDefault();
                $.ajax({
                    url: '<?php echo base_url() ?>login',
                    type: "POST",
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function() {
                        $("#login_btn").prop("disabled", true);
                        $("#login_btn").html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Authenticating...');
                    },
                    success: function(data) {
                        var response = data;
                        if (response.status == 200) {
                            let timerInterval;
                            Swal.fire({
                                icon: "success",
                                html: response.msg,
                                timer: 2000,
                                timerProgressBar: false,
                                didOpen: () => {
                                    Swal.showLoading();
                                },
                                willClose: () => {
                                    clearInterval(timerInterval);
                                }
                            }).then((result) => {
                                if (result.dismiss === Swal.DismissReason.timer) {
                                    window.location.href = "<?php echo base_url() ?>dashboard";
                                }
                            });

                        } else if (response.status == 400 || response.status == 401) {
                            Swal.fire({
                                title: "Warning",
                                text: response.msg,
                                icon: "warning"
                            });
                        } else if (response.status == 500) {
                            Swal.fire({
                                title: "Error",
                                text: response.msg,
                                icon: "error"
                            });
                        }
                    },
                    error: function(e) {
                        Swal.fire({
                            title: "Error",
                            text: "",
                            icon: "error"
                        });
                    },
                    complete: function() {
                        $("#login_btn").prop("disabled", false);
                        $("#login_btn").html('Sign Me In');
                    }
                });
            }));
        });
    </script>
</body>

</html>