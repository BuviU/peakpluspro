<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">
				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Document Browser</h4>
					</div>
				</div>
				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="col-md-12">
							<div class="card">
								<div class="body mt-2">
									<div class="card" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Search Documents
											</div>
										</div>
										<div class="body">
											<div class="row ">
												<label class="col-md-2">Document Name<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-10">
													<input type="text" name="doc_name" id="doc_name" class="form-control" placeholder="Enter Document Name" required>
												</div>
											</div>
											<div class="row mt-4">
												<div class="col-md-12 mb-3">
													<button type="button" id="btn_advance_search" class="btn btn-warning float-right px-5">Advanced Search</button>
													<a href="<?php echo base_url('documents/browse'); ?>" class="btn btn-light float-left"> <i class="bi bi-arrow-clockwise"></i> Refresh</a>
													<button type="button" id="btn_search" class="btn btn-dark float-right me-2"> <i class="bi bi-search"></i> Search</button>
												</div>
											</div>
										</div>
									</div>
									<!-- advancde search card -->
									<div id="advanced_search_card" class="card d-none" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Advanced Search Settings
											</div>
										</div>
										<div class="body">
											<form id="form-advance-search">
												<div class="row">
													<label class="form-label col-md-3">Parent System<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<select name="system" id="system" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a System...</option>
															<?php
															foreach ($systems as $system) { ?>
																<option value="<?php echo $system['system_id'] ?>"><?php echo $system['system_name'] ?></option>
															<?php
															}
															?>
														</select>
													</div>
												</div>
												<br>
												<div class="row">
													<label class="form-label col-md-3">Document Category<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<select name="category" id="category" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Category...</option>
														</select>
													</div>
												</div>
												<input type="hidden" name="cat_name" id="cat_name">
												<br>
												<div class="row">
													<label class="form-label col-md-3">Document Registry<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<select name="registry" id="registry" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Registry...</option>
														</select>
													</div>
												</div>
												<input type="hidden" name="registry_name" id="registry_name">
												<br>
												<div class="row">
													<label class="form-label col-md-3">Date Range<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<div class="row">
															<div class="col-6">
																<div class="input-group">
																	<input type="date" id="date1" name="date_from" class="form-control" placeholder="Date 1" aria-label="Date 1" aria-describedby="basic-addon2">
																	<span class="input-group-text" id="basic-addon2"><i class="bi bi-calendar-date"></i></span>
																</div>
															</div>
															<div class="col-6">
																<div class="input-group">
																	<input type="date" id="date2" name="date_to" class="form-control" placeholder="Date 1" aria-label="Date 1" aria-describedby="basic-addon2">
																	<span class="input-group-text" id="basic-addon2"><i class="bi bi-calendar-date"></i></span>
																</div>
															</div>
														</div>
													</div>
												</div>
												<br>
												<div class="row">
													<label class="form-label col-md-3">Location<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<select name="location" id="location" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Location...</option>
															<?php
															foreach ($locations as $location) { ?>
																<option value="<?php echo $location['location_id'] ?>"><?php echo $location['location_name'] ?></option>
															<?php
															}
															?>
														</select>
													</div>
													<input type="hidden" name="location_name" id="location_name">
												</div>
												<br>
												<div class="row">
													<label class="form-label col-md-3">Cost Center<font color="#FF0000"><strong>*</strong></font></label>
													<div class="col-md-9">
														<select name="cost_center" id="cost_center" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Cost Center...</option>
														</select>
													</div>
												</div>
												<br>
												<div class="row">
													<div class="col-md-12 my-3">
														<button type="submit" class="btn btn-dark float-right px-3"> <i class="bi bi-search"></i> Search</button>
													</div>
												</div>
											</form>
										</div>
									</div>
									<!-- Search result card -->
									<div id="search_result" class="card" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Search Results
											</div>
										</div>
										<div class="body">
											<div class="row">
												<div id="search_result" class="col-md-12">
													<div class="table-responsive">
														<table class="table table-hover js-basic-example dataTable table-custom">
															<thead class="thead-light">
																<tr>
																	<th style="width: 5%;">#</th>
																	<th style="width: 15%;">Category</th>
																	<th style="width: 15%;">Registry</th>
																	<th>Document Name</th>
																	<th style="width: 5%;">Actions</th>
																</tr>
															</thead>
															<tbody>
																<!-- itertate through $documents array -->
															</tbody>
														</table>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>

	<script>
		$(document).ready(function() {
			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});
			// show forward form
			$('#btn_advance_search').click(function() {
				// if advanced search form is not visible
				if ($('#advanced_search_card').hasClass('d-none')) {
					// show the form
					$('#advanced_search_card').removeClass('d-none');
					// hide the button
					$('#btn_advance_search').html('<i class="bi bi-x-circle-fill"></i> Close Advanced Search');
				} else {
					// hide the form
					$('#advanced_search_card').addClass('d-none');
					// show the button
					$('#btn_advance_search').html('<i class="bi bi-search"></i> Advanced Search');
				}
			});

			// system select on change event
			$('#system').on('change', function() {
				var system_id = $(this).val();
				if (system_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_system_categories'); ?>/" + system_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#category').html('<option value="0">Select a Category...</option>');
							$.each(response, function(index, value) {
								$('#category').append('<option value="' + value.id + '">' + value.category_name + '</option>');
							});
						}
					});
				}
			});

			// category select on change event
			$('#category').on('change', function() {
				var category_id = $(this).val();
				if (category_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_category_registries'); ?>/" + category_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#registry').html('<option value="0">Select a Registry...</option>');
							$.each(response, function(index, value) {
								$('#registry').append('<option value="' + value.id + '">' + value.registry_name + '</option>');
							});
						}
					});
				}
			});

			// location select on change event
			$('#location').on('change', function() {
				var location_id = $(this).val();
				if (location_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_cost_centers'); ?>/" + location_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
							$.each(response, function(index, value) {
								$('#cost_center').append('<option value="' + value.cost_center_id + '">' + value.cost_center_name + '</option>');
							});
						}
					});
				}
			});

			function populateTable(data) {
				// append the table rows with pagination
				var table = $('#search_result').find('table').DataTable();
				table.clear().draw();
				$.each(data, function(index, value) {
					table.row.add([
						index + 1,
						value.category_name,
						value.registry_name,
						value.name,
						'<button onclick="window.open(\'<?php echo base_url('documents/view/'); ?>' + value.id + '\', \'_blank\')" class="btn btn-light"><i class="bi bi-eye"></i></button>' +
						'<button onclick="window.open(\'<?php echo base_url('/documents/forward/'); ?>' + value.id + '\', \'_blank\')" class="btn btn-primary ml-2"><i class="bi bi-share"></i></button>'
					]).draw(false);
				});
			}

			// #doc_name on enter key press
			$('#doc_name').keypress(function(event) {
				if (event.keyCode == 13) {
					$('#btn_search').click();
				}
			});

			$('#btn_search').click(function() {
				// hide advance search form
				$('#advanced_search_card').addClass('d-none');
				var doc_name = $('#doc_name').val();

				if (!doc_name) {
					Swal.fire({
						icon: 'warning',
						title: 'Warning',
						text: "Please enter a document name to search.",
					});
					return;
				}

				// ajax call
				$('#loadingModal').modal('show');
				$.ajax({
					url: '<?= base_url() ?>documents/browse/search',
					type: 'POST',
					data: {
						doc_name: doc_name
					},
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							// console.log(response);
							populateTable(response.data);
						} else {
							var table = $('#search_result').find('table').DataTable();
							table.clear().draw();
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						}
					},
					error: function(response) {
						var table = $('#search_result').find('table').DataTable();
						table.clear().draw();
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: response.message,
						});
					}
				});
			});

			$('#form-advance-search').on('submit', function(event) {
				event.preventDefault();
				$('#loadingModal').modal('show');
				$.ajax({
					url: '<?= base_url('documents/browse/advanced_search') ?>',
					type: 'POST',
					data: $(this).serialize(),
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							populateTable(response.data);
						} else {
							var table = $('#search_result').find('table').DataTable();
							table.clear().draw();
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						}
					},
					error: function(response) {
						var table = $('#search_result').find('table').DataTable();
						table.clear().draw();
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: response.message,
						});
					}
				});
			});

		});
	</script>
</body>

</html>