<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>DOCX Viewer</title>

	<style>
		.docx-container {
			border: 1px solid #ccc;
			padding: 10px;
		}
	</style>
</head>

<body>

	<div id="docx-container" class="docx-container" style="display: flex; justify-content: center;"></div>
	<div id="docx-container3" class="docx-container3">

	</div>

	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jszip.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/docx-preview.js"></script>

	<script>
		$(document).ready(function() {
			fetch("<?php echo base_url(); ?>temp/<?php echo $document_id; ?>.docx")
				.then(response => response.blob())
				.then(blob => {
					const options = {
						inWrapper: false,
						ignoreWidth: false,
						ignoreHeight: true
					};

					docx.renderAsync(blob, document.getElementById("docx-container"), null, options)
						.then(() => {
							deleteTempDoc();
						})
						.catch(error => {
							// Handle rendering errors here
							deleteTempDoc();
							console.error("Error rendering document:", error);
							// Optionally, you can display an error message to the user
							document.getElementById("docx-container").innerHTML = "<h3 style='text-align: center'>There was an error rendering the document. Please try again. <br> You can download the document and then open it.</h3>";
						});
				})
				.catch(error => {
					// Handle fetch errors here
					deleteTempDoc();
					console.error("Error fetching document:", error);
				});


			function deleteTempDoc() {
				// ajax to delete the file
				$.ajax({
					url: "<?php echo base_url(); ?>documents/view/deleteTempDoc/<?php echo $document_id; ?>",
					type: "GET",
					dataType: "json",
					success: function(response) {
						console.log("Temp doc deleted!");
					},
					error: function(xhr, status, error) {
						console.log(xhr.responseText);
					}
				});
			}
		});
	</script>
</body>

</html>