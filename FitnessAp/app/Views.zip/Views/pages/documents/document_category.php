<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">
				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Document Categories</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<!-- <div class="header">
								<div class="d-flex">
									<div class="me-auto">
										<h2>Document Category Setup</h2>
									</div>
								</div>
							</div> -->

							<div class="body mt-4">
								<div class="card" style="border: 1px solid #e5e5e5; margin-top: -20px;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Document Category Setup
										</div>
									</div>
									<div class="card-body">
										<form accept-charset="UTF-8" id="doc_cat_insert_form">
											<div class="row">
												<div class="col-md-12 d-flex align-items-center">
													<label class="form-label">Parent System<font color="#FF0000"><strong>*</strong></font></label>
												</div>
												<div class="col-md-12">
													<select name="system_id" id="system_id" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select</option>
														<?php
														// $selected = "";
														foreach ($systems as $system) {
															// if ($system['system_id'] == $systems_id) {
															// 	$selected = "selected";
															// } else {
															// 	$selected = "";
															// }
															// echo '<option value="' . $system['system_id'] . '" ' . $selected . ' >' . $system['system_name'] . '</option>';
															echo '<option value="' . $system['system_id'] . '" >' . $system['system_name'] . '</option>';
														}
														?>
													</select>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-md-12 d-flex align-items-center">
													<label class="form-label">Document Category<font color="#FF0000"><strong>*</strong></font></label>
												</div>
												<div class="col-md-12">
													<input type="text" class="form-control" name="category_name" id="category_name" placeholder="Enter Category Name">
												</div>
											</div>
											<div class="row">
												<div class="col-md-12 mt-3">
													<button type="submit" class="btn btn-primary float-right px-5">Add</button>
												</div>
											</div>
										</form>
									</div>
								</div>

								<div id="table-div" class="card d-none" style="border: 1px solid #e5e5e5;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 13px;">
											Available Document Categories
											<span id="category_count" class="badge bg-dark ms-2"></span>
										</div>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table class="table table-hover js-basic-example dataTable table-custom">
												<thead class="thead-light">
													<tr>
														<th style="width: 5%;">#</th>
														<th style="width: 20%;">System</th>
														<th>Category Name</th>
														<th style="width: 5%;">Actions</th>
													</tr>
												</thead>
												<tbody>
													<!-- itertate through $categories array -->

												</tbody>
											</table>
										</div>
									</div>
								</div>
								<div class="alert alert-danger d-none" role="alert">
									<!-- show errors -->
									<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- menu_item Edit offcanvas -->
		<div class="offcanvas offcanvas-end" id="categoryEditOffcanvas" aria-labelledby="categoryEditOffcanvasLabel">
			<div class="offcanvas-header">
				<h5 id="categoryEditOffcanvasLabel">Update Category Details</h5>
				<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body">
				<div class="">
					<div class="">
						<form id="category_update_form">
							<div class="">
								<div class="">
									<div class="row clearfix">
										<div class="col-md-12">
											<div class="px-2">
												<div class="header" style="margin-top: -10px;">
													<h2 class="my-4 c-header text-primary">Enter Category Details</h2>
												</div>
												<div class="">
													<input type="hidden" name="category_id_edit" id="category_id_edit" class="form-control" required>
													<input type="hidden" name="category_name_old_edit" id="category_name_old_edit" class="form-control" required>
													<input type="hidden" name="system_id_edit" id="system_id_edit" class="form-control" required>
													<div class="row clearfix mt-3">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Category Name<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="category_name_edit" id="category_name_edit" class="form-control" placeholder="" required>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<button type="submit" class="btn btn-primary px-5 my-3"><i class="bi bi-check-circle-fill"></i>&nbsp;&nbsp;Update</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>



	<!-- Javascript -->
	<?= view('layouts/footer'); ?>

	<script>
		$(document).ready(function() {

			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// filter by system_id
			$('#system_id').change(function(e) {
				var system_id = $('#system_id').val();
				if (system_id != 0) {
					// ajax call
					$.ajax({
						url: '<?php echo base_url(); ?>documents/category/load_categories/' + system_id,
						type: 'GET',
						data: {},
						dataType: 'json',
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							if (response.status == 200) {
								// loop through response.data and set data to table
								var table_data = '';
								var x = 1;
								$.each(response.data, function(index, value) {
									table_data += '<tr>';
									table_data += '<td>' + x + '</td>';
									table_data += '<td>' + value.system_name + '</td>';
									table_data += '<td>' + value.category_name + '</td>';
									table_data += '<td style="width: 5%;" >';
									table_data += '<div class="dropup">';
									table_data += '<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
									table_data += '<i class="bi bi-three-dots-vertical"></i>';
									table_data += '</button>';
									table_data += '<ul class="dropdown-menu" style="z-index: 99999;">';
									table_data += '<li><a class="dropdown-item edit_category_btn" href="#" data-category-id="' + value.id + '">Edit</a></li>';
									<?php
									// check if the user is super admin, then show delete btn
									if ($user_role == 1) {
									?>
										table_data += '<li><a class="dropdown-item text-danger delete_category_btn" href="#" data-category-id="' + value.id + '">Delete</a></li>';
									<?php } ?>
									table_data += '</ul>';
									table_data += '</div>';
									table_data += '</td>';
									table_data += '</tr>';
									x++;
								});
								// set table_data to table tbody
								$('.table tbody').html(table_data);
								// set category_count
								$('#category_count').html(response.data.length + " items found.");
								$('#table-div').removeClass('d-none');
								$('.alert').addClass('d-none');
							} else if (response.status <= 500) {
								$('#table-div').addClass('d-none');
								$('.alert').removeClass('d-none');
								$('.alert').html('<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;' + response.message);
							} else if (response.status >= 500) {
								$('#table-div').addClass('d-none');
								$('.alert').removeClass('d-none');
								$('.alert').html('<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;' + response.message);
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
				else{
					$('#table-div').addClass('d-none');
					$('.alert').addClass('d-none');
				}
			});

			// doc_cat_insert_form submit
			$('#doc_cat_insert_form').submit(function(e) {
				$('#loadingModal').modal('show');
				e.preventDefault();
				$.ajax({
					url: '<?php echo base_url(); ?>documents/category/create',
					type: 'POST',
					data: new FormData(this),
					contentType: false,
					processData: false,
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 201) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
								showConfirmButton: false,
								timer: 1500
							}).then(function() {
								location.reload();
							});
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
					},

					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					} // Fix: Moved closing parentheses to the correct place
				});
			});

			// edit_category_btn click
			$('.table tbody').on("click", ".edit_category_btn", function() {
				$('#loadingModal').modal('show');
				// get menu_item id
				var category_id = $(this).attr('data-category-id');
				// ajax call
				$.ajax({
					url: '<?php echo base_url(); ?>documents/category/show/' + category_id,
					type: 'GET',
					data: {},
					dataType: 'json',
					beforeSend: function() {
						$('#categoryEditOffcanvas button[type="submit"]').attr('disabled', true);
						$('#categoryEditOffcanvas button[type="submit"]').html('Please wait...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							$('#category_id_edit').val(response.data.id);
							$('#category_name_edit').val(response.data.category_name);
							$('#category_name_old_edit').val(response.data.category_name);
							$('#system_id_edit').val(response.data.system_id);
							$('#categoryEditOffcanvas').offcanvas('show');
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
						$('#categoryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#categoryEditOffcanvas button[type="submit"]').html('Update');
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
						$('#categoryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#categoryEditOffcanvas button[type="submit"]').html('Update');
					}
				});
			});

			$('#category_update_form').submit(function(e) {
				e.preventDefault();
				$('#loadingModal').modal('show');
				// get category_id
				var category_id = $('#category_id_edit').val();
				$.ajax({
					url: '<?php echo base_url(); ?>documents/category/update/' + category_id,
					type: 'PUT',
					data: {
						"category_name_edit": $('#category_name_edit').val(),
						"system_id": $('#system_id_edit').val(),
					},
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
								showConfirmButton: false,
								timer: 1500
							}).then(function() {
								location.reload();
							});
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
						$('#categoryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#categoryEditOffcanvas button[type="submit"]').html('Update');
					},

					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
						$('#categoryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#categoryEditOffcanvas button[type="submit"]').html('Update');
					} // Fix: Moved closing parentheses to the correct place
				});
			});


			// delete_category_btn click
			$('.table tbody').on("click", ".delete_category_btn", function() {
				Swal.fire({
					title: 'Please Confirm',
					html: "<label class='data-text'>Are you sure you want to delete this document category ? Please note that this action cannot be undone, so proceed with caution.</label>",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#d33',
					cancelButtonColor: '#3085d6',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					if (result.isConfirmed) {
						$('#loadingModal').modal('show');
						// get category_id 
						var category_id = $(this).attr('data-category-id');
						// ajax call
						$.ajax({
							url: '<?php echo base_url(); ?>documents/category/delete/' + category_id,
							type: 'DELETE',
							data: {},
							dataType: 'json',
							beforeSend: function() {
								$('.delete_category_btn').attr('disabled', true);
								$('.delete_category_btn').html('<i class="fa fa-spinner fa-spin"></i> Deleting...');
							},
							success: function(response) {
								$('#loadingModal').modal('hide');
								if (response.status == 200) {
									Swal.fire({
										icon: 'success',
										title: 'Success',
										text: response.message,
										showConfirmButton: false,
										timer: 1500
									}).then(function() {
										location.reload();
									});
								} else if (response.status <= 500) {
									Swal.fire({
										icon: 'warning',
										title: 'Warning',
										text: response.message,
									});
								} else if (response.status >= 500) {
									Swal.fire({
										icon: 'error',
										title: 'Oops...',
										text: response.message,
									});
								}
								$('.delete_category_btn').attr('disabled', false);
								$('.delete_category_btn').html('Delete');
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('#loadingModal').modal('hide');
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: 'Something went wrong! Please try again later.',
								});
								$('.delete_category_btn').attr('disabled', false);
								$('.delete_category_btn').html('Delete');
							}
						});
					}
				})

			});
		});
	</script>
</body>

</html>