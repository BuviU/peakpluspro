<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Just a moment...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">View Documents</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<!-- <div class="header">
								<h2>Document Forwarding Setup</h2>
							</div> -->

							<div class="body mt-2">
								<?php if ($document == null) {
									if ($message != "") {
										echo '<div class="alert alert-danger" role="alert">' . $message . '</div>';
									} else {
								?>
										<div class="d-flex flex-column text-center">
											<div class="alert alert-danger" role="alert">
												<h6>Please select a document to view and come back.</h6><a href="<?php echo base_url(); ?>documents/browse" class="mt-2 btn btn-danger px-4" style="width: fit-content">Browse Documents</a>
											</div>
										</div>

									<?php
									}
									?>
								<?php } else { ?>
									<div class="card" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Document View & Other Actions
											</div>
										</div>

										<div class="card-body">
											<div class="row">
												<div class="col-lg-12 col-sm-12">
													<div class="row">
														<div class="col-lg-6 col-sm-12">
															<div class="img-thumbnail h-100 d-flex justify-content-center align-items-center">
																<?php
																$url = "";
																$base_url = base_url() . "assets/images/formats";
																switch ($document['type']) {
																	case "pdf":
																		$url = $base_url . "/pdf.png";
																		break;
																	case "doc":
																		$url = $base_url . "/doc.png";
																		break;
																	case "docx":
																		$url = $base_url . "/docx.png";
																		break;
																	case "xls":
																		$url = $base_url . "/xls.png";
																		break;
																	case "xlsx":
																		$url = $base_url . "/xlsx.png";
																		break;
																	case "csv":
																		$url = $base_url . "/csv.png";
																		break;
																	case "jpg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "jpeg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "png":
																		$url = $base_url . "/png.png";
																		break;
																	case "bmp":
																		$url = $base_url . "/bmp.png";
																		break;
																	case "tiff":
																		$url = $base_url . "/tiff.png";
																		break;
																	case "tif":
																		$url = $base_url . "/tiff.png";
																		break;
																}
																?>
																<img src="<?php echo $url; ?>" alt="placeholder" width="50%" class="img-fluid">
															</div>
														</div>
														<div class="col-lg-6 col-sm-12">
															<div class="d-flex flex-column">
																<div class="d-flex flex-column" id="doc-info">
																	<div class="d-flex">
																		<div class="me-auto">
																			<h6 class="text-primary mb-3"><strong>Document Details</strong></h6>
																		</div>
																		<div>
																			<!-- <button class="btn btn-light"><i class="bi bi-three-dots-vertical"></i> More Details</button> -->
																		</div>
																	</div>
																	<div class="form-group d-flex flex-column">
																		<span>Document Name</span>
																		<label><strong><?php echo $document['name'] . "   (" . strtoupper($document['type']) . ")"; ?></strong></label>
																	</div>
																	<div class="form-group d-flex flex-column" style="margin-top: -15px;">
																		<span>Uploaded At</span>
																		<label><strong><?php echo $document['uploaded_at']; ?></strong></label>
																	</div>
																</div>
																<div class="d-flex flex-column" style="margin-top: -10px;">
																	<div class="d-flex">
																		<button class="btn btn-dark me-1" data-bs-toggle="modal" data-bs-target="#exampleModal" style="width: fit-content;"><i class="bi bi-three-dots-vertical"></i> More Details</button>
																		<button class="btn btn-dark" id="open_timline_n_comments" style="width: fit-content;"><i class="bi bi-clock-history"></i> Timeline & Comments </button>
																	</div>
																	<div class="btn-group mt-2" role="group" aria-label="Basic example">
																		<button id="download_btn" data-document-type="<?php echo $document['type']; ?>" data-document-id="<?php echo $document['document_id']; ?>" type="button" class="btn btn-warning px-4"><i class="bi bi-download"></i>&nbsp;&nbsp;&nbsp;Download</button>
																		<button id="open_btn" type="button" data-document-id="<?php echo $document['document_id']; ?>" data-document-type="<?php echo $document['type']; ?>" class="btn btn-warning px-4 open_btn"><i class="bi bi-box-arrow-up-right"></i>&nbsp;&nbsp;&nbsp;Open</button>
																		<button id="print_btn" type="button" data-document-id="<?php echo $document['document_id']; ?>" data-document-type="<?php echo $document['type']; ?>" class="btn btn-warning px-4"><i class="bi bi-printer"></i>&nbsp;&nbsp;&nbsp;Print</button>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="row mt-3">
												<div id="timeline_n_comments" class="col-12 d-none">
													<ul class="nav nav-tabs" id="myTab" role="tablist">
														<li class="nav-item" role="presentation">
															<button class="nav-link active" id="timeline-tab" data-bs-toggle="tab" data-bs-target="#timeline-tab-pane" type="button" role="tab" aria-controls="timeline-tab-pane" aria-selected="true">Changes Timeline</button>
														</li>
														<li class="nav-item" role="presentation">
															<button class="nav-link" id="comments-tab" data-bs-toggle="tab" data-bs-target="#comments-tab-pane" type="button" role="tab" aria-controls="comments-tab-pane" aria-selected="false">Comments</button>
														</li>
													</ul>
													<div class="tab-content" id="myTabContent">
														<div class="tab-pane fade show active" id="timeline-tab-pane" role="tabpanel" aria-labelledby="timeline-tab" tabindex="0">
															<!-- PLaceholder -->
															<div id="timeline-placehoder" class="placeholder-wave d-none my-4">
																<span class="placeholder w-50"></span>
																<span class="placeholder w-75"></span>
																<span class="placeholder w-25"></span>
															</div>
															<!-- placeholder end -->
															<ol id="timeline-timeline" class="timeline">
																<!-- <li class="timeline-item">
																	<span class="timeline-item-icon | faded-icon">
																		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
																			<path fill="none" d="M0 0h24v24H0z" />
																			<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />
																		</svg>
																	</span>
																	<div class="timeline-item-description">
																		<i class="avatar | small">
																			<img src="https://assets.codepen.io/285131/winking-girl.png" />
																		</i>
																		<div class="d-flex flex-column">
																			<div>
																				<span><a href="#">Hasintha Nayanajith </a>uploaded the document.</span>
																			</div>
																			<div>
																				<small>2023-12-10 at 10:32 AM</small>
																			</div>
																		</div>
																	</div>
																</li> -->
															</ol>
														</div>
														<div class="tab-pane fade" id="comments-tab-pane" role="tabpanel" aria-labelledby="comments-tab" tabindex="0">
															<div class="timeline-item mb-4">
																<!-- <span class="timeline-item-icon | avatar-icon">
																	<i class="avatar">
																		<img src="https://assets.codepen.io/285131/hat-man.png" />
																	</i>
																</span> -->
																<div class="d-flex w-100 border rounded p-1">
																	<style>
																		.comment-bx {
																			border: none;
																			outline: none;
																		}

																		.comment-bx:focus {
																			border: none;
																			outline: none;
																			box-shadow: none;
																		}
																	</style>
																	<input id="comment-textbox" class="comment-bx m-1 w-100" placeholder="Add a comment..." />
																	<button id="insert_comment" class="btn btn-dark"><i class="bi bi-send-fill"></i></button>
																</div>
															</div>
															<ol id="comments-timeline" class="timeline">
																<!-- PLaceholder -->
																<div id="comments-placehoder" class="placeholder-wave d-none my-3">
																	<span class="placeholder w-50"></span>
																	<span class="placeholder w-75"></span>
																	<span class="placeholder w-25"></span>
																</div>
																<!-- placeholder end -->
																<!-- <li class="timeline-item" style="width: 100%;">
																	<span class="timeline-item-icon | faded-icon">
																		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
																			<path fill="none" d="M0 0h24v24H0z" />
																			<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />
																		</svg>
																	</span>
																	<div class="timeline-item-description" style="width: 100%;">
																		<i class="avatar | small">
																			<img src="https://assets.codepen.io/285131/winking-girl.png" />
																		</i>
																		<div class="d-flex flex-column alert alert-info">
																			<div class="d-flex flex-column">
																				<span><a href="#"><strong>Hasintha Nayanajith</strong></a></span>
																				<span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
																			</div>
																			<div>
																				<a href="#">
																					<small><strong>2023-12-10 at 10:32 AM</strong></small>
																				</a>
																			</div>
																		</div>
																	</div>
																</li> -->
															</ol>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- more details -->
		<?php if ($document != null) { ?>
			<div class="modal fade" id="exampleModal" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-header">
							<h1 class="modal-title fs-5" id="exampleModalLabel">Document Details</h1>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body p-4">
							<div class="row">
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Parent System</span>
										<label class="form-label text-dark"><?php echo $document['system_name']; ?></label>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Category Name</span>
										<label class="form-label text-dark"><?php echo $document['category_name']; ?></label>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Registry Name</span>
										<label class="form-label text-dark"><?php echo $document['registry_name']; ?></label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Location Name</span>
										<label class="form-label text-dark"><?php echo $document['location_name']; ?></label>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Cost Center Name</span>
										<label class="form-label text-dark"><?php echo $document['cost_center_name']; ?></label>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Uploaded By</span>
										<label class="form-label text-dark"><?php echo $document['employee_name']; ?></label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12 d-flex flex-column">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Document Name</span>
										<label class="form-label text-dark"><?php echo $document['name'] . "   (" . strtoupper($document['type']) . ")"; ?></label>
									</div>
								</div>
								<div class="col-6"></div>
							</div>
							<div class="row">
								<div class="col-12 d-flex flex-column">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Description</span>
										<p class="form-label text-dark"><?php echo ($document['description']) ? $document['description'] : " - - -"; ?></p>
									</div>
								</div>
								<div class="col-6"></div>
							</div>
							<div class="row">
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Parent System</span>
										<label class="form-label text-dark"><?php echo $document['uploaded_by']; ?></label>
									</div>
								</div>
								<div class="col-4">
									<div class="form-group d-flex flex-column">
										<span style="font-weight: 400;">Uploaded At</span>
										<label class="form-label text-dark"><?php echo $document['uploaded_at']; ?></label>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-primary px-3" data-bs-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
			</div>

		<?php } ?>

	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>
	<script src="<?php echo base_url(); ?>assets/js/print.min.js"></script>

	<script>
		$(document).ready(function() {
			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// wait 2 seconds and click #open_timline_n_comments btn
			setTimeout(function() {
				$('#open_timline_n_comments').click();
			}, 1000);

			// open_btn click event
			$('.open_btn').click(function() {
				var document_id = $(this).attr('data-document-id');
				var document_type = $(this).attr('data-document-type');

				if (document_type == 'pdf' || document_type == 'png' || document_type == 'jpeg' || document_type == 'jpg') {
					// file can be opened in a new tab
					var url = '<?= base_url(); ?>/documents/view/get_document_content/' + document_id;
					var win = window.open(url, '_blank');
					// ajax call to get the document content
					// var url = '<?= base_url(); ?>documents/view/get_document_content/' + document_id;
					// $.ajax({
					// 	url: url,
					// 	type: 'GET',
					// 	data:{},
					// 	success: function(response) {
					// 		console.log(response); // Access properties like response.document_id
					// 	},
					// 	error: function(xhr, ajaxOptions, thrownError) {
					// 		console.log(xhr.status);
					// 		console.log(thrownError);
					// 	}
					// });


				} else if (document_type == 'doc' || document_type == 'docx') {
					// get document content
					var url = '<?= base_url(); ?>/documents/view/get_docx_content/' + document_id;
					var win = window.open(url, '_blank');

				} else {
					// file can be opened in a new tab
					Swal.fire({
						icon: 'warning',
						title: 'Cannot Open.',
						text: 'Sorry, this document type is not supported for preview. Please download and open it.',
					});
				}
			});

			// print_btn click event
			$('#print_btn').click(function() {
				var document_id = $(this).attr('data-document-id');
				var document_type = $(this).attr('data-document-type');

				if (document_type == 'pdf' || document_type == 'png' || document_type == 'jpeg' || document_type == 'jpg') {
					// print file
					if (document_type == 'pdf') document_type = 'pdf';
					else document_type = 'image';
					var url = '<?= base_url(); ?>/documents/view/get_document_content/' + document_id;
					printJS({
						printable: url,
						type: document_type,
						showModal: true
					})
				} else {
					// file can be opened in a new tab
					Swal.fire({
						icon: 'warning',
						title: 'Not Printable.',
						text: 'Sorry, this document type is not supported for print. You can download and open it.',
					});
				}
			});

			// download_btn click event
			$('#download_btn').click(function() {
				var document_id = $(this).attr('data-document-id');
				var document_type = $(this).attr('data-document-type');

				// create an anchor tag to download the document
				var url = '<?= base_url(); ?>/documents/view/get_document_content/' + document_id;

				// Create a temporary anchor element
				var anchor = document.createElement('a');
				anchor.href = url;
				anchor.download = document_id + '.' + document_type;
				anchor.click();
			});

			// timeline-tab click event
			$('#timeline-tab').click(function() {
				// click open_timline_n_comments btn
				$('#open_timline_n_comments').click();
			});

			// open_timline_n_comments click event
			$('#open_timline_n_comments').click(function() {
				$('#timeline_n_comments').removeClass('d-none');
				// show placeholder
				$('#timeline-placehoder').removeClass('d-none');
				// load timeline data
				var document_id = <?php echo $document_id; ?>;
				var url = '<?= base_url(); ?>/documents/timeline/get_document_timeline/' + document_id;
				$.ajax({
					url: url,
					type: 'GET',
					data: {},
					dataType: 'json',
					success: function(response) {

						if (response.status == 200) {
							// populate timeline
							$('#timeline-timeline').html('');
							var timeline = '';
							// loop through the response
							$.each(response.data, function(index, value) {
								// create timeline item
								var action_type = value.action_type;
								var action_icon = '';
								if (value.action_type == 1) {
									action_type = 'Uploaded the document.';
									action_icon = 'cloud-computing.png';
								} else if (value.action_type == 3) {
									action_type = 'Forwarded the document.';
									action_icon = 'arrow.png';
								} else if (value.action_type == 4) {
									action_type = 'Viewed the document content.';
									action_icon = 'view.png';
								}
								timeline += '<li class="timeline-item">';
								timeline += '<span class="timeline-item-icon | faded-icon">';
								// timeline += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">';
								// timeline += '<path fill="none" d="M0 0h24v24H0z" />';
								// timeline += '<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />';
								// timeline += '</svg>';
								timeline += '<img src="<?php echo base_url() ?>assets/images/formats/' + action_icon + '" width="24" height="24" />';
								timeline += '</span>';
								timeline += '<div class="timeline-item-description">';
								timeline += '<i class="avatar | small">';
								timeline += '<img src="<?php echo base_url() ?>assets/images/formats/user.png"/>';
								timeline += '</i>';
								timeline += '<div class="d-flex flex-column">';
								timeline += '<div>';
								timeline += '<span><a href="#">' + value.action_by_name + ' ' + '</a> ' + action_type + '</span>';
								timeline += '</div>';
								timeline += '<div>';
								timeline += '<small>' + value.action_time + '</small>';
								timeline += '</div>';
								timeline += '</div>';
								timeline += '</div>';
							});

							$('#timeline-timeline').html(timeline);

						} else {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message ? response.message : 'Something went wrong'
							});
						}
						// hide placeholder
						$('#timeline-placehoder').addClass('d-none');
					},
					error: function(xhr, ajaxOptions, thrownError) {
						console.log(xhr.status);
						console.log(thrownError);
						// hide placeholder
						$('#timeline-placehoder').addClass('d-none');
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: 'Something went wrong'
						});
					}
				});
			});

			// #comment-textbox enter button clicked
			$('#comment-textbox').keypress(function(e) {
				if (e.which == 13) {
					$('#insert_comment').click();
				}
			});

			// insert_comment click event
			$('#insert_comment').click(function() {
				var comment = $('#comment-textbox').val();
				var document_id = <?php echo $document_id; ?>;
				if (comment == '') {
					Swal.fire({
						icon: 'warning',
						title: 'Warning',
						text: 'Please enter a comment.'
					});
				} else {
					// insert comment
					var url = '<?= base_url(); ?>/documents/timeline/new_comment';
					$.ajax({
						url: url,
						type: 'POST',
						data: {
							document_id: document_id,
							comment: comment
						},
						dataType: 'json',
						success: function(response) {
							if (response.status == 200) {
								// clear comment textbox
								$('#comment-textbox').val('');
								// get comments
								get_comments(document_id);
							} else {
								Swal.fire({
									icon: 'warning',
									title: 'Warning',
									text: response.message ? response.message : 'Something went wrong'
								});
							}
						},
						error: function(xhr, ajaxOptions, thrownError) {
							console.log(xhr.status);
							console.log(thrownError);
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: 'Something went wrong'
							});
						}
					});
				}
			});

			// comments-tab click event
			$('#comments-tab').click(function() {
				var document_id = <?php echo $document_id; ?>;
				// get comments
				get_comments(document_id);
			});

			// get_comments function
			function get_comments(document_id) {
				// show placeholder
				$('#comments-placehoder').removeClass('d-none');
				// get comments
				var url = '<?= base_url(); ?>/documents/timeline/get_comments/' + document_id;
				$.ajax({
					url: url,
					type: 'GET',
					data: {},
					dataType: 'json',
					success: function(response) {
						console.log(response);
						if (response.status == 200) {
							// populate comments
							$('#comments-timeline').html('');
							var comments = '';
							// comments += '<li class="timeline-item mb-3">';
							// comments += '<span class="timeline-item-icon |  avatar-icon">';
							// comments += '<i class="avatar">';
							// comments += '<img src="https://assets.codepen.io/285131/hat-man.png" />';
							// comments += '</i>';
							// comments += '</span>';
							// comments += '<div class="d-flex w-100 border rounded p-1">';
							// comments += '</i>';
							// comments += '<style>';
							// comments += '.comment-bx {border: none;outline: none;';
							// comments += '.comment-bx:focus {border: none;outline: none;box-shadow: none;}';
							// comments += '</style>';
							// comments += '<input id="comment-textbox" class="comment-bx m-1 w-100" placeholder="Add a comment..." />';
							// comments += '<button id="insert_comment" class="btn btn-dark insert_comment">';
							// comments += '<i class="bi bi-send-fill"></i>';
							// comments += '</button>';
							// comments += '</div>';
							// comments += '</li>';

							// loop through the response
							$.each(response.data, function(index, value) {
								// create comment item
								comments += '<li class="timeline-item" style="width: 100%; margin-top: 5px;">';
								comments += '<span class="timeline-item-icon | faded-icon">';
								// comments += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">';
								// comments += '<path fill="none" d="M0 0h24v24H0z" />';
								// comments += '<path fill="currentColor" d="M12.9 6.858l4.242 4.243L7.242 21H3v-4.243l9.9-9.9zm1.414-1.414l2.121-2.122a1 1 0 0 1 1.414 0l2.829 2.829a1 1 0 0 1 0 1.414l-2.122 2.121-4.242-4.242z" />';
								// comments += '</svg>';
								comments += '<img src="<?php echo base_url() ?>assets/images/formats/speech-bubble.png" width="24" height="24" />';
								comments += '</span>';
								comments += '<div class="timeline-item-description" style="width: 100%;">';
								comments += '<i class="avatar | small">';
								comments += '<img src="<?php echo base_url() ?>assets/images/formats/user.png"/>';
								comments += '</i>';
								comments += '<div class="d-flex flex-column alert alert-secondary" style="width: 100%; border: none; border-radius: 20px; background-color: rgb(235,245,255);">';
								comments += '<div class="d-flex flex-column">';
								comments += '<span><a href="#"><strong>' + value.action_by_name + '</strong></a></span>';
								comments += '<small class="mb-2">' + value.action_time + '</small>';
								comments += '<span>' + value.comment + '</span>';
								comments += '</div>';
								comments += '<div>';
								comments += '<a href="#">';
								comments += '</a>';
								comments += '</div>';
								comments += '</div>';
								comments += '</div>';
							});

							$('#comments-timeline').html(comments);
							// hide placeholder
							$('#comments-placehoder').addClass('d-none');

						} else {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message ? response.message : 'Something went wrong'
							});
						}
						// hide placeholder
						$('#comments-placehoder').addClass('d-none');
					},
					error: function(xhr, ajaxOptions, thrownError) {
						console.log(xhr.status);
						console.log(thrownError);
						// hide placeholder
						$('#comments-placehoder').addClass('d-none');
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: 'Something went wrong'
						});
					}
				});

			};

		});
	</script>
</body>

</html>