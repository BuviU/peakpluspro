<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">
				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Upload Documents</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<div class="body mt-4">
								<div class="card" style="border: 1px solid #e5e5e5; margin-top: -20px;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Document Upload Setup
										</div>
									</div>
									<div class="card-body">
										<form id="document_upload_form" enctype="multipart/form-data">
											<div class="border-bottom mb-4">
												<h5 style="font-weight: 300; color: grey;">Upload Details</h5>
											</div>
											<div class="row">
												<label class="form-label col-md-3">Parent System<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="system" id="system" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select Parent System...</option>
														<?php
														foreach ($systems as $system) { ?>
															<option value="<?php echo $system['system_id']; ?>"><?php echo $system['system_name']; ?></option>
														<?php
														}
														?>
													</select>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Category<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="category" id="category" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Category...</option>
													</select>
												</div>
											</div>
											<input type="hidden" name="cat_name" id="cat_name">
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Registry<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<select name="registry" id="registry" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select a Registry...</option>
													</select>
												</div>
											</div>
											<input type="hidden" name="registry_name" id="registry_name">
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Name<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="doc_name" id="doc_name" placeholder="Enter Document Name" required>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Document Description</label>
												<div class="col-md-9">
													<textarea name="description" id="description" cols="30" rows="10" class="form-control" style="height: 100px;" placeholder="Additional Notes ..."></textarea>
												</div>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Location<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="location_name" id="location_name" value="<?php echo $location_name; ?>" readonly required>
												</div>
												<input type="text" class="form-control" name="location" id="location" value="<?php echo $location_id; ?>" readonly hidden>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Cost Center<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="cost_center_name" id="cost_center_name" value="<?php echo $cost_center_name; ?>" readonly required>
												</div>
												<input type="text" class="form-control" name="cost_center" id="cost_center" value="<?php echo $cost_center_id; ?>" readonly hidden>
											</div>
											<br>
											<div class="row">
												<label class="form-label col-md-3">Employee Code<font color="#FF0000"><strong>*</strong></font></label>
												<div class="col-md-9">
													<input type="text" class="form-control" name="emp_code" id="emp_code" value="<?php echo $emp_code; ?>" readonly required>
												</div>
											</div>
											<br>
											<br>
											<div class="border-bottom mb-3">
												<h5 style="font-weight: 300; color: grey;">Choose Documents</h5>
											</div>
											<div class="row">
												<!-- <label class="form-label col-md-3">Choose Documents<font color="#FF0000"><strong>*</strong></font></label> -->
												<div class="col-md-12 d-flex flex-column">
													<button type="button" class="btn btn-dark w-100" id="selectDocumentBtn" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-paperclip"></i>Attach</button>
													<div class="mt-3">
														<table id="scannedDocumentTable" class="table table-sm table-bordered align-middle" style="font-size: 12px; font-weight: 300; color: grey;">
															<td class="table-secondary" colspan="5">Scanned Documents</td>
															</tr>
														</table>
													</div>
													<div>
														<table id="browsedDocumentTable" class="table table-sm table-bordered align-middle" style="font-size: 12px; font-weight: 300; color: grey;">
															<td class="table-secondary" colspan="4">Browsed Documents</td>
															</tr>
														</table>
													</div>
												</div>
											</div>
											<br>
											<br>
											<div class="border-bottom mb-2">
											</div>
											<div class="row">
												<div class="col-md-12 mt-2">
													<button type="submit" class="btn btn-primary float-right px-5"> <i class="bi bi-upload"></i>&nbsp;&nbsp;&nbsp;Upload</button>
												</div>
											</div>
										</form>
									</div>
								</div>
								<!-- <div class="card" id="scannedImagesCard" style="border: 1px solid #e5e5e5; margin-top: -20px; display: none;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Thumbnails of Scanned Pages
										</div>
									</div>
									<div class="card-body">
										<div id="images"></div>
									</div>
								</div> -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Choose Document Modal -->
		<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h1 class="modal-title fs-5" id="staticBackdropLabel">Choose the Document to Upload</h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<div class="d-flex flex-column text-center mt-3">
							<button type="button" onclick="scanToPdfWithThumbnails();" class="btn btn-success w-100 mb-2"><i class="bi bi-upc-scan"></i>&nbsp;&nbsp;&nbsp;Scan a Document</button>
							<small> -- or browse documents -- </small>
							<div class="input-group">
								<div class="custom-file">
									<input type="file" class="form-control w-100" accept=".pdf, .doc, .docx, .tiff, .jpg, .png, .bmp, .pdf, .xls, .xlsx, .csv, .doc, .docx" id="fileInput" multiple>
									<!-- Hidden input store base64 PDF string -->
									<input type="hidden" name="base64_pdf" id="base64_pdf">
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary px-4" data-bs-dismiss="modal">OK</button>
					</div>
				</div>
			</div>
		</div>
		<!-- upload Summary Modal -->
		<div class="modal fade" id="uploadSummaryModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="uploadSummaryModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="text-center"><strong>Upload Summary</strong></h5>
						<h1 class="modal-title fs-5" id="staticBackdropLabel"></h1>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center mt-3">
							<img id="loading_gif" src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<div style="width: 250px;" class="progress my-3" role="progressbar" aria-label="Animated striped example" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
								<div id="upload_progress" class="progress-bar progress-bar-striped bg-success progress-bar-animated" style="width: 0%"></div>
							</div>
							<label id="upload_progress_label" class="form-label">Uploading Files...Please Wait</label>
						</div>
						<div class="mt-3">
							<div class="alert alert-light">
								<label id="doc_up_succeded_lbl" class="form-label text-success">Succeded</label>
								<ul id="doc_up_succeded">
								</ul>
							</div>
							<div class="alert alert-light">
								<label id="doc_up_failed_lbl" class="form-label text-danger">Failed</label>
								<ul id="doc_up_failed">
								</ul>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button id="upSummaryModalCloseBtn" onclick="closeUploadSummaryModal()" type="button" class="btn btn-dark px-4">OK</button>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>
	<script src="<?php echo base_url(); ?>assets/js/scanner.js" type="text/javascript"></script>
	<!-- <script src="<?php echo base_url() ?>/assets/scannerjs/scanner.js" type="text/javascript"></script> -->
	<script src="<?php echo base_url(); ?>assets/js/pdf-lib.min.js" type="text/javascript"></script>

	<script>
		function closeUploadSummaryModal() {
			$('#uploadSummaryModal').modal('hide');
			location.reload();
		}

		var document_scanned_successfully = false;
		// global variable to store scanned file (files are in base64 format)
		var scannedFiles = [];
		var scannedPageCountArray = [];
		LoadScannedFilesToTable();

		/** Scan: output PDF original and JPG thumbnails */
		function scanToPdfWithThumbnails() {
			scanner.scan(displayImagesOnPage, {
				"output_settings": [{
						"type": "return-base64",
						"format": "pdf",
						"pdf_text_line": "By ${USERNAME} on ${DATETIME}"
					},
					{
						"type": "return-base64-thumbnail",
						"format": "jpg",
						"thumbnail_height": 140
					}
				]
			});
		}

		/** Processes the scan result */
		function displayImagesOnPage(successful, mesg, response) {
			if (!successful) { // On error
				console.error('Failed: ' + mesg);
				return;
			}

			if (successful && mesg != null && mesg.toLowerCase().indexOf('user cancel') >= 0) { // User cancelled.
				console.info('User cancelled');
				return;
			}

			var thumbnails = scanner.getScannedImages(response, false, true); // returns an array of ScannedImage
			scannedPageCountArray.push(thumbnails.length);
			var scannedImages = scanner.getScannedImages(response, true, false); // returns an array of ScannedImage
			for (var i = 0;
				(scannedImages instanceof Array) && i < scannedImages.length; i++) {
				var scannedImage = scannedImages[i];
				processOriginal(scannedImage);
			}
			for (var i = 0;
				(thumbnails instanceof Array) && i < thumbnails.length; i++) {
				var thumbnail = thumbnails[i];
				// processThumbnail(thumbnail);
			}
		}

		/** Images scanned so far. */
		var imagesScanned = [];

		/** Processes an original */
		function processOriginal(scannedImage) {
			imagesScanned.push(scannedImage);
			scannedFiles.push(scannedImage.src);
			LoadScannedFilesToTable();
		}

		/** Processes a thumbnail */
		function processThumbnail(scannedImage) {
			var elementImg = scanner.createDomElementFromModel({
				'name': 'img',
				'attributes': {
					'class': 'scanned view',
					'src': scannedImage.src,
					'onclick': 'openPDF()'
				}
			});
		}

		/** Upload scanned images by submitting the form */
		function submitFormWithScannedImages() {
			if (scanner.submitFormWithImages('form1', imagesScanned, function(xhr) {
					if (xhr.readyState == 4) { // 4: request finished and response is ready
						document.getElementById('server_response').innerHTML = "<h2>Response from the server: </h2>" + xhr.responseText;
						document.getElementById('images').innerHTML = ''; // clear images
						imagesScanned = [];
					}
				})) {
				document.getElementById('server_response').innerHTML = "Submitting, please stand by ...";
			} else {
				document.getElementById('server_response').innerHTML = "Form submission cancelled. Please scan first.";
			}
		}

		// view scanned file button click event, delegated to the #scannedDocumentTable
		$('#scannedDocumentTable').on('click', '.view_s_file', function() {
			// get the file id
			const file_id = $(this).data('file-id');
			// get the file from scannedFiles array
			const file = scannedFiles[file_id];
			var base64Pdf = file;
			// Create a data URI for the PDF
			var pdfDataUri = base64Pdf;
			// Open the PDF in a new tab
			var newTab = window.open();
			newTab.document.write('<embed width="100%" height="100%" src="' + pdfDataUri + '" type="application/pdf">');
			// Close the document to finalize it
			newTab.document.close();
		});

		// Function to format file size
		function formatBytes(bytes, decimals = 2) {
			if (bytes === 0) return '0 Bytes';
			const k = 1024;
			const dm = decimals < 0 ? 0 : decimals;
			const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
			const i = Math.floor(Math.log(bytes) / Math.log(k));
			return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
		}

		function GetFileFormatImage(format) {
			var base_url = "<?php echo base_url() ?>assets/images/formats/"
			var format = format.toLowerCase();
			switch (format) {
				case "pdf":
					return base_url + "pdf.png";
					break;
				case "doc":
					return base_url + "doc.png";
					break;
				case "docx":
					return base_url + "docx.png";
					break;
				case "tiff":
					return base_url + "tiff.png";
					break;
				case "jpg":
					return base_url + "jpeg.png";
					break;
				case "jpeg":
					return base_url + "jpeg.png";
					break;
				case "png":
					return base_url + "png.png";
					break;
				case "bmp":
					return base_url + "bmp.png";
					break;
				case "xls":
					return base_url + "xls.png";
					break;
				case "xlsx":
					return base_url + "xlsx.png";
					break;
				case "csv":
					return base_url + "csv.png";
					break;
				default:
					return base_url + "unknown.png";
					break;
			}
		}

		// append scanned files to the scannedDocumentTable
		function LoadScannedFilesToTable() {
			// clear the #scannedDocumentTable rows except the first row
			$('#scannedDocumentTable tr').slice(1).remove();
			if (scannedFiles.length > 0) {
				// loop through scannedFiles array
				for (let i = 0; i <= scannedFiles.length - 1; i++) {
					const fileName = "Scan_" + (i + 1) + " (" + scannedPageCountArray[i] + " Pages)"; // get the file name
					// get size of the base64 string in bytes
					const fileSize = Math.round((scannedFiles[i].length * (3 / 4)) - 2);
					const fileFormat = "PDF"; // get the file format (extension)
					// add a new row to the #scannedDocumentTable
					$('#scannedDocumentTable').append('<tr><td style="font-weight:400;" class="ps-3"><div class="d-flex"><img width="15px" class="me-2" src="' + GetFileFormatImage(fileFormat) + '" />' + (i + 1) + ". " + (fileName.length > 150 ? fileName.substring(0, 150) + "..." : fileName) + '</div></td><td style="width: 60px;font-weight:400;">' + fileFormat.toUpperCase() + '</td><td style="width: 80px;font-weight:400;">' + formatBytes(fileSize) + '</td><td style="width: 20px;"><button type="button" class="btn btn-sm btn-light view_s_file" data-file-id="' + i + '"><i class="bi bi-eye-fill"></i></button></td><td style="width: 20px;"><button type="button" class="btn btn-sm btn-danger remove_s_file" data-file-id="' + i + '"><i class="bi bi-trash"></i></button></td></tr>');
				}
			} else {
				// add a new row to the #scannedDocumentTable to say "No file selected"
				$('#scannedDocumentTable').append('<tr colspan="5"><td style="font-weight: 400;" class="ps-3">No file scanned!</td></tr>');
			}
		}

		// remove scanned file button click event, delegated to the #scannedDocumentTable
		$('#scannedDocumentTable').on('click', '.remove_s_file', function() {

			Swal.fire({
				title: 'Please Confirm',
				text: "Are you sure you want to remove this scanned document ?",
				icon: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#d33',
				cancelButtonColor: '#3085d6',
				confirmButtonText: 'Yes, remove it!'
			}).then((result) => {
				if (result.isConfirmed) {
					// get the file id
					const file_id = $(this).data('file-id');
					// remove the file from scannedFiles array
					scannedFiles.splice(file_id, 1);
					scannedPageCountArray.splice(file_id, 1);
					// load the scanned files table
					LoadScannedFilesToTable();
				}
			})
		});
	</script>

	<style>
		img.scanned {
			height: 140px;
			/** Sets the display size */
			margin-right: 12px;
			border-radius: 15px;
			border: 2px solid #e1e1e1;
		}

		img.scanned:hover {
			height: 140px;
			/** Sets the display size */
			margin-right: 12px;
			border-radius: 15px;
			border: 5px solid #000;
		}

		img.view {
			cursor: pointer;
		}

		div#images {
			margin-top: 10px;
		}
	</style>

	<script>
		$(document).ready(function() {

			// global array to store browsed files
			var browsedFiles = [];
			LoadBrowsedFilesTable();

			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// view scanned images
			$('#view_scanned_doc_btn').click(function() {
				openPDF();
			});

			// fileInput on change event
			$('#fileInput').on('change', function() {
				const fileInput = document.getElementById('fileInput');

				// Check if a file is selected
				if (fileInput.files.length > 0) {

					// loop through all the selected files
					for (let i = 0; i <= fileInput.files.length - 1; i++) {
						const fileName = fileInput.files.item(i).name; // get the file name
						const fileSize = fileInput.files.item(i).size; // get the file size
						const fileFormat = getFileFormat(fileName); // get the file format (extension)

						// Check if the file format is allowed
						if (isAllowedFileFormat(fileFormat)) {
							// push the file to browsedFiles array
							browsedFiles.push(fileInput.files[i]);
							// if(fileFormat == "pdf"){
							// 	// compress the pdf file
							// 	var compressedPdfFile = compressPDF(fileInput.files[i]);
							// 	// push the compressed pdf file to browsedFiles array
							// 	browsedFiles.push(compressedPdfFile);
							// }else{
							// 	// push the file to browsedFiles array
							// 	browsedFiles.push(fileInput.files[i]);
							// }
							// load the browsed files table
							LoadBrowsedFilesTable();
						} else {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: (fileName.length > 50 ? fileName.substring(0, 50) + "..." : fileName) + 'is not a valid file.',
							});
							continue;
						}
					}

				} else {
					// // clear the #browsedDocumentTable rows except the first row
					// $('#browsedDocumentTable tr').slice(1).remove();
					// // add a new row to the #browsedDocumentTable to say "No file selected"
					// $('#browsedDocumentTable').append('<tr><td class="ps-3">No file selected!</td><td></td><td style="width: 20px;"></td></tr>');
					// Swal.fire({
					// 	icon: 'error',
					// 	title: 'Oops...',
					// 	text: 'No file selected! Please select a file.',
					// });
				}
			});

			// async function compressPDF(fileInput) {
			// 	// Get the input file
			// 	const file = fileInput;

			// 	// Load the PDF file
			// 	const existingPdfBytes = await file.arrayBuffer();
			// 	const pdfDoc = await PDFLib.PDFDocument.load(existingPdfBytes);

			// 	// Create a new PDF with compressed images
			// 	const pdfBytes = await pdfDoc.save();

			// 	// Create a Blob from the compressed PDF bytes
			// 	const compressedPdfBlob = new Blob([pdfBytes], {
			// 		type: 'application/pdf'
			// 	});

			// 	// unique file name
			// 	var uniqueFileName = file.name;

			// 	// Create a new File from the Blob
			// 	const compressedPdfFile = new File([compressedPdfBlob], uniqueFileName, {
			// 		type: 'application/pdf'
			// 	});

			// 	// log file name and compressed file size
			// 	console.log("File Name: " + compressedPdfFile.name + " | File Size: " + formatBytes(compressedPdfFile.size));

			// 	return compressedPdfFile;
			// }

			// Function to get the file format (extension)
			function getFileFormat(fileName) {
				const dotIndex = fileName.lastIndexOf('.');
				if (dotIndex !== -1) {
					return fileName.substring(dotIndex + 1).toLowerCase();
				}
				return 'Unknown';
			}

			// Function to check if the file format is allowed
			function isAllowedFileFormat(fileFormat) {
				const allowedFormats = ['pdf', 'doc', 'docx', 'tiff', 'jpg', 'png', 'jpeg', 'bmp', 'xls', 'csv', 'xlsx'];
				return allowedFormats.includes(fileFormat);
			}

			function LoadBrowsedFilesTable() {
				// clear the #browsedDocumentTable rows except the first row
				$('#browsedDocumentTable tr').slice(1).remove();
				if (browsedFiles.length > 0) {
					// loop through browsedFiles array
					for (let i = 0; i <= browsedFiles.length - 1; i++) {
						const fileName = browsedFiles[i].name; // get the file name
						const fileSize = browsedFiles[i].size; // get the file size
						const fileFormat = getFileFormat(fileName); // get the file format (extension)
						// add a new row to the #browsedDocumentTable
						$('#browsedDocumentTable').append('<tr><td style="font-weight:400;" class="ps-3"><div class="d-flex"><img width="15px" class="me-2" src="' + GetFileFormatImage(fileFormat) + '" />' + (i + 1) + ". " + (fileName.length > 150 ? fileName.substring(0, 150) + "..." : fileName) + '</div></td><td style="width: 60px;font-weight:400;">' + fileFormat.toUpperCase() + '</td><td style="width: 80px;font-weight:400;">' + formatBytes(fileSize) + '</td><td style="width: 20px;"><button type="button" class="btn btn-sm btn-danger remove_b_file" data-file-id="' + i + '"><i class="bi bi-trash"></i></button></td></tr>');
					}
				} else {
					// add a new row to the #browsedDocumentTable to say "No file selected"
					$('#browsedDocumentTable').append('<tr colspan="4"><td style="font-weight:400;" class="ps-3">No file selected!</td></tr>');
				}
			}

			// remove browsed file button click event, delegated to the #browsedDocumentTable
			$('#browsedDocumentTable').on('click', '.remove_b_file', function() {
				// get the file id
				const file_id = $(this).data('file-id');
				// remove the file from browsedFiles array
				browsedFiles.splice(file_id, 1);
				// load the browsed files table
				LoadBrowsedFilesTable();
			});

			// system select on change event
			$('#system').on('change', function() {
				var system_id = $(this).val();
				var access_token;
				if (system_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_system_categories'); ?>/" + system_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#category').html('<option value="0">Select a Category...</option>');
							$.each(response, function(index, value) {
								$('#category').append('<option value="' + value.id + '">' + value.category_name + '</option>');
							});
						}
					});
				}
			});

			// category select on change event
			$('#category').on('change', function() {
				var category_id = $(this).val();
				if (category_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_category_registries'); ?>/" + category_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#registry').html('<option value="0">Select a Registry...</option>');
							$.each(response, function(index, value) {
								$('#registry').append('<option value="' + value.id + '">' + value.registry_name + '</option>');
							});
						}
					});
				}
			});

			// Document Upload Form Submit
			$('#document_upload_form').submit(function(e) {
				e.preventDefault();

				// get selected system id
				var system_id = $('#system').val();
				// get selected category id
				var category_id = $('#category').val();
				// get selected registry id
				var registry_id = $('#registry').val();
				// get file input
				var fileInput = document.getElementById('fileInput');

				if (system_id == 0 || category_id == 0 || registry_id == 0) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Please fill all the required fields!',
					});
				} else if (browsedFiles.length == 0 && scannedFiles.length == 0) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Please browse or scan documents!',
					});
				} else {
					UploadDocument();
				}
			});

			/**********************************************************************/
			/**********************************************************************/
			/**********************************************************************/

			function UploadDocument() {

				// show summary modal
				$('#loading_gif').removeClass('d-none');
				$('#upSummaryModalCloseBtn').disabled = true;
				$('#uploadSummaryModal').modal('show');
				$('#upload_progress_label').text('Iniitializing Upload...');
				$('#upload_progress').css('width', '0%');
				$('#upload_progress').text('0%');

				// get all upload file count
				var upload_file_count = browsedFiles.length + scannedFiles.length;
				// upload erros
				var browsed_file_upload_fails = 0;
				var browsed_file_upload_fail_messages = [];
				var scanned_file_upload_fails = 0;
				var scanned_file_upload_fail_messages = [];

				// upload successes
				var browsed_file_upload_successes = 0;
				var scanned_file_upload_successes = 0;

				// foreach browsed_file in browsed_file array, create a unique_id. and then push both browsed_file and unique_id to browsed_file_upload_array as an object
				var browsed_file_upload_array = [];
				for (let i = 0; i <= browsedFiles.length - 1; i++) {
					var browsed_file = browsedFiles[i];
					var browsed_file_unique_id = Date.now() + i;
					browsed_file_upload_array.push({
						unique_id: browsed_file_unique_id,
						file: browsed_file,
						name: browsed_file.name
					});
				}

				// foreach scanned_file in scanned_file array, create a unique_id. and then push both scanned_file and unique_id to scanned_file_upload_array as an object
				var scanned_file_upload_array = [];
				for (let i = 0; i <= scannedFiles.length - 1; i++) {
					var scanned_file = scannedFiles[i];
					var scanned_file_unique_id = Date.now() + i;
					scanned_file_upload_array.push({
						unique_id: scanned_file_unique_id,
						file: scanned_file,
						name: "Scan_" + (i + 1)
					});
				}

				// upload document
				var formData = new FormData($('#document_upload_form')[0]);

				$.ajax({
					type: "POST",
					url: "<?php echo base_url(); ?>documents/upload/init_upload",
					data: formData,
					processData: false,
					contentType: false,
					// async: false,
					success: function(response) {
						var response = JSON.parse(response);
						if (response.status == 200) {
							// upload scanned files
							for (let i = 0; i <= scanned_file_upload_array.length - 1; i++) {
								$('#upload_progress_label').text('Uploading Scanned Files...');
								// set form_data to upload scanned file
								var file = scanned_file_upload_array[i].file;
								var FileUploadForm = new FormData();
								FileUploadForm.append('base64', file);
								FileUploadForm.append('file_indentifier', scanned_file_upload_array[i].unique_id); // this is just a unique id to identify the file. after response from the server, 'll use this id to identify the file
								FileUploadForm.append('upload_id', response.data.upload_id);
								FileUploadForm.append('system', $('#system').val());
								$.ajax({
									type: "POST",
									url: "<?php echo base_url(); ?>documents/upload/upload_base64",
									data: FileUploadForm,
									processData: false,
									contentType: false,
									// async: false,
									success: function(response) {
										var response = JSON.parse(response);
										if (response.status == 200) {
											scanned_file_upload_successes++;
											var progress = Math.ceil((scanned_file_upload_successes + browsed_file_upload_successes) / upload_file_count * 100);
											$('#upload_progress').css('width', progress + '%');
											$('#upload_progress').text(progress + '%');
											// find file name from browsed_file_upload_array using the unique_id
											var file_name = scanned_file_upload_array.find(x => x.unique_id == response.file_indentifier);
											if (file_name != undefined) {
												Append_li('success', file_name.name);
											}
											// show summary modal
											ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
										} else {
											scanned_file_upload_fails++;
											scanned_file_upload_fail_messages.push(response.message);
											// find file name from browsed_file_upload_array using the unique_id
											var file_name = scanned_file_upload_array.find(x => x.unique_id == response.file_indentifier);
											if (file_name != undefined) {
												Append_li('failed', file_name.name + " => " + response.message);
											}
											// show summary modal
											ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
										}
									},
									error: function(response) {
										scanned_file_upload_fails++;
										Append_li('failed', "Something went wrong! 1 Scanned file upload failed!");
										ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
									},
								});
								// wait 1 second before uploading next file
								setTimeout(function() {}, 1000);

							}
							// upload browsed files
							for (let i = 0; i <= browsed_file_upload_array.length - 1; i++) {
								$('#upload_progress_label').text('Uploading Browsed Files...');
								var file = browsed_file_upload_array[i].file;
								var FileUploadForm = new FormData();
								FileUploadForm.append('file', file);
								FileUploadForm.append('file_indentifier', browsed_file_upload_array[i].unique_id);
								FileUploadForm.append('upload_id', response.data.upload_id);
								FileUploadForm.append('system', $('#system').val());
								$.ajax({
									type: "POST",
									url: "<?php echo base_url(); ?>documents/upload/upload_file",
									data: FileUploadForm,
									// async: false,
									processData: false,
									contentType: false,
									success: function(response) {
										var response = JSON.parse(response);
										if (response.status == 200) {
											browsed_file_upload_successes++;
											var progress = Math.ceil((scanned_file_upload_successes + browsed_file_upload_successes) / upload_file_count * 100);
											$('#upload_progress').css('width', progress + '%');
											$('#upload_progress').text(progress + '%');
											// find file name from browsed_file_upload_array using the unique_id
											var file_name = browsed_file_upload_array.find(x => x.unique_id == response.file_indentifier);
											if (file_name != undefined) {
												Append_li('success', file_name.name);
											}
											// show summary modal
											ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
										} else {
											browsed_file_upload_fails++;
											// find file name from browsed_file_upload_array using the unique_id
											var file_name = browsed_file_upload_array.find(x => x.unique_id == response.file_indentifier);
											if (file_name != undefined) {
												Append_li('failed', file_name.name + " => " + response.message);
											}
											// show summary modal
											ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
										}
									},
									error: function(response) {
										browsed_file_upload_fails++;
										Append_li('failed', "Something went wrong! 1 Browsed file upload failed!");
										ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes);
									},
								});
								// wait 1 second before uploading next file
								setTimeout(function() {}, 1000);
							}

						} else if (response.status >= 400 && response.status < 500) {
							$('#uploadSummaryModal').modal('hide');
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status == 500) {
							$('#uploadSummaryModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Error',
								text: response.message,
							});
						}
					},
					error: function(response) {
						$('#uploadSummaryModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Error',
							text: 'Something went wrong!',
						});
					},
				});

			}

			function ShowUploadSummary(upload_file_count, browsed_file_upload_fails, browsed_file_upload_fail_messages, scanned_file_upload_fails, scanned_file_upload_fail_messages, browsed_file_upload_successes, scanned_file_upload_successes) {
				// succeeded (:count)
				$('#doc_up_succeded_lbl').text('Succeded (' + (browsed_file_upload_successes + scanned_file_upload_successes) + ')');
				// faield (:count)
				$('#doc_up_failed_lbl').text('Failed (' + (browsed_file_upload_fails + scanned_file_upload_fails) + ')');

				// if upload_file_count == browsed_file_upload_successes + scanned_file_upload_successes + browsed_file_upload_fails + scanned_file_upload_fails
				if (upload_file_count == browsed_file_upload_successes + scanned_file_upload_successes + browsed_file_upload_fails + scanned_file_upload_fails) {
					$('#upload_progress_label').text('Upload Completed!');
					$('#upload_progress').css('width', '100%');
					$('#upload_progress').text('100%');
					$('#loading_gif').addClass('d-none');
					$('#upSummaryModalCloseBtn').disabled = false;
				}
			}

			function Append_li(type, filename) {
				if (type == 'success') {
					$('#doc_up_succeded').append('<li class="d-flex my-1" style="font-weight: 500"><img width="15px" height="15px" class="me-2" src="<?php echo base_url(); ?>assets/images/status/checked.png" /><span><strong>' + filename + '</strong> uploaded successfully.</span></li>');
				} else if (type == 'failed') {
					$('#doc_up_failed').append('<li class="d-flex my-1" style="font-weight: 500"><img width="15px" height="15px" class="me-2" src="<?php echo base_url(); ?>assets/images/status/cancel.png" /><span><strong>' + filename + '</strong></span></li>');
				}
			}

		});
	</script>
</body>

</html>