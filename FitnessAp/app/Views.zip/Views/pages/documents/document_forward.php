<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Forward Documents</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">

							<div class="body mt-2">
								<?php if ($document == null) {
									if ($message != "") {
										echo '<div class="alert alert-danger" role="alert">' . $message . '</div>';
									} else {
								?>
										<div class="d-flex flex-column text-center">
											<div class="alert alert-danger" role="alert">
												<h6>Please select a document to forward and come back.</h6><a href="<?php echo base_url(); ?>documents/browse" class="mt-2 btn btn-danger px-4" style="width: fit-content">Browse Documents</a>
											</div>
										</div>

									<?php
									}
									?>
								<?php } else { ?>
									<div class="card" style="border: 1px solid #e5e5e5;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Document Forwarding Setup
											</div>
										</div>

										<div class="card-body">
											<div class="row">
												<div class="col-lg-12 col-sm-12">
													<div class="row">
														<div class="col-lg-6 col-sm-12">
															<div class="img-thumbnail h-100 d-flex justify-content-center align-items-center">
																<?php
																$url = "";
																$base_url = base_url() . "assets/images/formats";
																switch ($document['type']) {
																	case "pdf":
																		$url = $base_url . "/pdf.png";
																		break;
																	case "doc":
																		$url = $base_url . "/doc.png";
																		break;
																	case "docx":
																		$url = $base_url . "/docx.png";
																		break;
																	case "xls":
																		$url = $base_url . "/xls.png";
																		break;
																	case "xlsx":
																		$url = $base_url . "/xlsx.png";
																		break;
																	case "csv":
																		$url = $base_url . "/csv.png";
																		break;
																	case "jpg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "jpeg":
																		$url = $base_url . "/jpeg.png";
																		break;
																	case "png":
																		$url = $base_url . "/png.png";
																		break;
																	case "bmp":
																		$url = $base_url . "/bmp.png";
																		break;
																	case "tiff":
																		$url = $base_url . "/tiff.png";
																		break;
																	case "tif":
																		$url = $base_url . "/tiff.png";
																		break;
																}
																?>
																<img src="<?php echo $url; ?>" alt="placeholder" width="50%" class="img-fluid">
															</div>
														</div>
														<div class="col-lg-6 col-sm-12">
															<div class="d-flex flex-column">
																<div class="d-flex flex-column" id="doc-info">
																	<h6 class="text-primary mb-3"><strong>Document Details</strong></h6>
																	<div class="form-group">
																		<label class="form-label">Document Name</label>
																		<input type="text" class="form-control" name="doc_name" id="doc_name" placeholder="" value="<?php echo $document['name']; ?>" disabled>
																	</div>
																	<div class="form-group">
																		<label class="form-label">Description</label>
																		<textarea class="form-control" name="description" id="description" rows="3" value="<?php echo $document['description']; ?>" disabled></textarea>
																	</div>
																	<div class="form-group">
																		<label class="form-label">Uploaded Date & Time</label>
																		<input type="text" class="form-control" name="uploaded_date" id="uploaded_date" placeholder="" value="<?php echo $document['uploaded_at']; ?>" disabled>
																	</div>
																</div>
																<div class="d-flex">
																	<button class="btn btn-warning p-2 px-4 m-2 ms-0" onclick="window.location.href='<?php echo base_url() . 'documents/view/' . $document_id ?>'"> <i class="bi bi-eye-fill"></i> View Document</button>
																	<button class="btn btn-dark p-2 px-3 m-2" id="btn-forward"> <i class="bi bi-forward-fill"></i> Forward Document</button>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="d-none card mt-1" id="forward-card" style="border: 1px solid #e5e5e5; margin-top: -20px;">
										<div class="card-header bg-dark text-light d-flex py-2">
											<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
												Document Forwarding Details
											</div>
										</div>
										<div class="card-body">
											<form id="form-forward">
												<input type="hidden" class="form-control" name="document_id" id="document_id" value="<?php echo $document_id; ?>" required>
												<div class="row">
													<label class="form-label col-md-2">Location</label>
													<div class="col-md-10">
														<select name="location" id="location" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Location...</option>
															<?php
															if (isset($locations)) {
																foreach ($locations as $location) {
																	echo '<option value="' . $location['location_id'] . '">' . $location['location_name'] . '</option>';
																}
															}
															?>
														</select>
													</div>
												</div>
												<br>

												<div class="row">
													<label class="form-label col-md-2">Cost Center</label>
													<div class="col-md-10">
														<select name="cost_center" id="cost_center" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Cost Center...</option>
														</select>
													</div>
												</div>
												<br>

												<div class="row">
													<label class="form-label col-md-2">Designation</label>
													<div class="col-md-10">
														<select name="designation" id="designation" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Designation...</option>
															<?php
															if (isset($designations)) {
																foreach ($designations as $designation) {
																	echo '<option value="' . $designation['designation_name'] . '">' . $designation['designation_name'] . '</option>';
																}
															}
															?>
														</select>
													</div>
												</div>
												<br>

												<div class="row">
													<label class="form-label col-md-2">Employee</label>
													<div class="col-md-10">
														<select name="employee" id="employee" class="js-example-basic-single form-control" style="width: 100%;">
															<option value="0">Select a Employee...</option>
														</select>
													</div>
												</div>
												<br>

												<div class="row">
													<label class="form-label col-md-2">Comment</label>
													<div class="col-md-10">
														<input type="text" class="form-control" name="comment" id="comment" placeholder="Add Comments...">
													</div>
												</div>

												<div class="row mt-4">
													<label class="form-label col-md-2"></label>
													<div class="col-md-10">
														<div class="form-check">
															<input id="is_finalized" class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
															<label class="form-check-label" for="flexCheckChecked">
																Mark as Finalized
															</label>
														</div>
													</div>
												</div>

												<div class=" row mt-4">
													<div class="float-end">
														<button type="submit" class=" btn btn-primary float-right px-5 float-end"> <i class="bi bi-forward-fill"></i> Forward Now</button>
													</div>
												</div>
											</form>
										</div>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<?= view('layouts/footer'); ?>

	<script>
		$(document).ready(function() {
			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});
			// show forward form
			$('#btn-forward').click(function() {
				$('#forward-card').removeClass('d-none');
				// scroll to the bottom
				$('html, body').animate({
					scrollTop: $("#forward-card").offset().top
				}, 100);
			});
			// location select on change event
			$('#location').on('change', function() {
				// #cost_center, #designation, #employee select options reset
				$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
				$('#designation').html('<option value="0">Select a Designation...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#cost_center').trigger('change');
				$('#designation').trigger('change');
				$('#employee').trigger('change');
				// get location_id
				var location_id = $(this).val();
				if (location_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_cost_centers'); ?>/" + location_id,
						dataType: "json",
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
							$.each(response, function(index, value) {
								$('#cost_center').append('<option value="' + value.cost_center_id + '">' + value.cost_center_name + '</option>');
							});
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
				else{
					ResetDesignations();
				}
			});
			// cost_center select on change event
			$('#cost_center').on('change', function() {
				// #designation, #employee select options reset
				$('#designation').html('<option value="0">Select a Designation...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#designation').trigger('change');
				$('#employee').trigger('change');
				// get cost_center_id
				var cost_center_id = $(this).val();
				if (cost_center_id != 0) {
					$.ajax({
						type: "POST",
						url: "<?php echo base_url('data/get_designations_from_employees'); ?>",
						dataType: "json",
						data: {
							'location': $('#location option:selected').text(),
							'cost_center': $('#cost_center option:selected').text()
						},
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							$('#designation').html('<option value="0">Select a Designation...</option>');
							$.each(response, function(index, value) {
								$('#designation').append('<option value="' + value.designation + '">' + value.designation + '</option>');
							});
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
			});

			// designation select on change event
			$('#designation').on('change', function() {
				// #employee select options reset
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#employee').trigger('change');
				// if both location and cost_center are selected
				if ($('#location').val() != 0 && $('#cost_center').val() != 0) {
					// get designation_id
					var designation_id = $('#designation option:selected').text();
					if (designation_id != 'Select a Designation...') {
						$.ajax({
							type: "POST",
							url: "<?php echo base_url('data/get_employees'); ?>",
							data: {
								'location': $('#location option:selected').text(),
								'cost_center': $('#cost_center option:selected').text(),
								'designation': designation_id
							},
							dataType: "json",
							success: function(response) {
								// console.log(response);
								$('#employee').html('<option value="0">Select a Employee...</option>');
								$.each(response, function(index, value) {
									$('#employee').append('<option value="' + value.emp_code + '">' + value.name + " - " + value.designation + '</option>');
								});
							}
						});
					}
				}
			});

			function ResetDesignations() {
				$('#cost_center').html('<option value="0">Select a Cost Center...</option>');
				$('#employee').html('<option value="0">Select a Employee...</option>');
				$('#cost_center').trigger('change');
				$('#employee').trigger('change');

				$.ajax({
					type: "GET",
					url: "<?php echo base_url('data/get_designations'); ?>",
					dataType: "json",
					success: function(response) {
						$('#designation').html('<option value="0">Select a Designation...</option>');
						$.each(response, function(index, value) {
							$('#designation').append('<option value="' + value.designation_name + '">' + value.designation_name + '</option>');
						});
					}
				});
			}

			// form submit
			$('#form-forward').submit(function(e) {
				e.preventDefault();
				var form_data = $(this).serialize();
				// get is_finalized value, and set it to 0 if not checked
				var is_finalized = 0;
				if ($('#is_finalized').is(":checked")) {
					is_finalized = 1;
				}
				form_data += '&is_finalized=' + is_finalized;
				$.ajax({
					type: "POST",
					url: "<?php echo base_url('documents/forward/forward_document'); ?>",
					data: form_data,
					dataType: "json",
					success: function(response) {
						if (response.status == 200) {
							// show success message
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
								showConfirmButton: false,
								timer: 1500
							}).then((result) => {
								if (result.dismiss === Swal.DismissReason.timer) {
									location.reload();
								}
							});
						} else if (response.status >= 400 && response.status < 500) {
							// show warning message
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});

						} else {
							// show error message
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
					}
				});
			});

		});
	</script>
</body>

</html>