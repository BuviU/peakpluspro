<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">
				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">Document Registry</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<div class="body mt-4">
								<div class="card" style="border: 1px solid #e5e5e5; margin-top: -20px;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 14px;">
											Document Registry Setup
										</div>
									</div>
									<div class="card-body">
										<form id="doc_reg_insert_form">
											<div class="row">
												<div class="col-md-12 d-flex align-items-center">
													<label class="form-label">Parent System<font color="#FF0000"><strong>*</strong></font></label>
												</div>
												<div class="col-md-12">
													<select name="system_id" id="system_id" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select</option>
														<?php
														// $selected = "";
														foreach ($systems as $system) {
															// if ($system['system_id'] == $system_id) {
															// 	$selected = "selected";
															// } else {
															// 	$selected = "";
															// }
															// echo '<option value="' . $system['system_id'] . '" ' . $selected . ' >' . $system['system_name'] . '</option>';
															echo '<option value="' . $system['system_id'] . '" >' . $system['system_name'] . '</option>';
														}
														?>
													</select>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-md-12 d-flex align-items-center">
													<label class="form-label">Document Category<font color="#FF0000"><strong>*</strong></font></label>
												</div>
												<div class="col-md-12">
													<select name="category_id" id="category_id" class="js-example-basic-single form-control" style="width: 100%;" required>
														<option value="0">Select</option>
													</select>
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-md-12 d-flex align-items-center">
													<label class="form-label">Document Registry Name<font color="#FF0000"><strong>*</strong></font></label>
												</div>
												<div class="col-md-12">
													<input type="text" class="form-control" name="registry_name" id="registry_name" placeholder="Enter Registry Name">
												</div>
											</div>
											<div class="row">
												<div class="col-md-12 mt-3">
													<button type="submit" class="btn btn-primary float-right px-5">Add</button>
												</div>
											</div>
										</form>
									</div>
								</div>
								<div id="table-div" class="card d-none" style="border: 1px solid #e5e5e5;">
									<div class="card-header bg-dark text-light d-flex py-2">
										<div class="d-flex mr-auto" style="font-weight: 700; font-size: 13px;">
											Available Document Registries
											<span id="registry_count" class="badge bg-dark ms-2"></span>
										</div>
									</div>
									<div class="card-body">
										<div class="table-responsive">
											<table class="table table-hover js-basic-example dataTable table-custom">
												<thead class="thead-light">
													<tr>
														<th style="width: 5%;">#</th>
														<th style="width: 20%;">Category</th>
														<th>Registry Name</th>
														<th style="width: 5%;">Actions</th>
													</tr>
												</thead>
												<tbody>
													<!-- itertate through $categories array -->
												</tbody>
											</table>
										</div>
									</div>
								</div>
								<div class="alert alert-danger d-none" role="alert">
									<!-- show errors -->
									<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- registry Edit offcanvas -->
		<div class="offcanvas offcanvas-end" id="registryEditOffcanvas" aria-labelledby="registryEditOffcanvasLabel">
			<div class="offcanvas-header">
				<h5 id="registryEditOffcanvasLabel">Update Registry Details</h5>
				<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body">
				<div class="">
					<div class="">
						<form id="registry_update_form">
							<div class="">
								<div class="">
									<div class="row clearfix">
										<div class="col-md-12">
											<div class="px-2">
												<div class="header" style="margin-top: -10px;">
													<h2 class="my-4 c-header text-primary">Enter Registry Details</h2>
												</div>
												<div class="">
													<input type="hidden" name="registry_id_edit" id="registry_id_edit" class="form-control" required>
													<input type="hidden" name="registry_name_old_edit" id="registry_name_old_edit" class="form-control" required>
													<input type="hidden" name="system_id_edit" id="system_id_edit" class="form-control" required>
													<div class="row clearfix mt-3">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Registry Name<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="registry_name_edit" id="registry_name_edit" class="form-control" placeholder="" required>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<button type="submit" class="btn btn-primary px-5 my-3"><i class="bi bi-check-circle-fill"></i>&nbsp;&nbsp;Update</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Loading Modal -->
		<div class="modal" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="loadingModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content" style="width: 300px; height: 80px; margin-left: 100px; margin-bottom: 100px;">
					<div class="modal-body">
						<div class="d-flex flex-column align-items-center justify-content-center">
							<img src="<?php echo base_url() ?>assets/images/loading.gif" width="30px">
							<label class="form-label">Just a moment...</label>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>



	<!-- Javascript -->
	<?= view('layouts/footer'); ?>


	<script>
		$(document).ready(function() {

			$('.js-example-basic-single').select2({
				placeholder: " Select",
				allowClear: true
			});

			// system_id select on change event
			$('#system_id').on('change', function() {
				// trigger category_id change event
				$('#category_id').html('');
				$('#category_id').trigger('change');
				var system_id = $(this).val();
				if (system_id != 0) {
					$.ajax({
						type: "GET",
						url: "<?php echo base_url('data/get_system_categories'); ?>/" + system_id,
						dataType: "json",
						success: function(response) {
							// console.log(response);
							$('#category_id').html('<option value="0">Select a Category...</option>');
							$.each(response, function(index, value) {
								$('#category_id').append('<option value="' + value.id + '">' + value.category_name + '</option>');
							});
						}
					});
				} else {
					$('#category_id').html('<option value="0">Select a Category...</option>');
				}
			});

			// filter registry by category
			$('#category_id').change(function(e) {
				var category_id = $('#category_id').val();
				if (category_id != null && category_id != 0) {
					// ajax call
					$.ajax({
						url: '<?php echo base_url(); ?>documents/registry/load_registry/' + category_id,
						type: 'GET',
						data: {},
						dataType: 'json',
						beforeSend: function() {
							$('#loadingModal').modal('show');
						},
						success: function(response) {
							$('#loadingModal').modal('hide');
							if (response.status == 200) {
								// loop through response.data and set data to table
								var table_data = '';
								var x = 1;
								$.each(response.data, function(index, value) {
									table_data += '<tr>';
									table_data += '<td>' + x + '</td>';
									table_data += '<td>' + value.category_name + '</td>';
									table_data += '<td>' + value.registry_name + '</td>';
									table_data += '<td style="width: 5%;" >';
									table_data += '<div class="dropup">';
									table_data += '<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">';
									table_data += '<i class="bi bi-three-dots-vertical"></i>';
									table_data += '</button>';
									table_data += '<ul class="dropdown-menu" style="z-index: 99999;">';
									table_data += '<li><a class="dropdown-item edit_registry_btn" href="#" data-registry-id="' + value.id + '">Edit</a></li>';
									<?php
									// check if the user is super admin, then show delete btn
									if ($user_role == 1) {
									?>
										table_data += '<li><a class="dropdown-item text-danger delete_registry_btn" href="#" data-registry-id="' + value.id + '">Delete</a></li>';
									<?php } ?>
									table_data += '</ul>';
									table_data += '</div>';
									table_data += '</td>';
									table_data += '</tr>';
									x++;
								});
								// set table_data to table tbody
								$('.table tbody').html(table_data);
								// set registry_count
								$('#registry_count').html(response.data.length + " items found.");
								$('#table-div').removeClass('d-none');
								$('.alert').addClass('d-none');
							} else if (response.status <= 500) {
								$('#table-div').addClass('d-none');
								$('.alert').removeClass('d-none');
								$('.alert').html('<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;' + response.message);
							} else if (response.status >= 500) {
								$('#table-div').addClass('d-none');
								$('.alert').removeClass('d-none');
								$('.alert').html('<i class="bi bi-bug-fill"></i>&nbsp;&nbsp;&nbsp;&nbsp;' + response.message);
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#loadingModal').modal('hide');
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
						}
					});
				}
				else{
					$('#table-div').addClass('d-none');
					$('.alert').addClass('d-none');
				}
			});

			// doc_reg_insert_form submit
			$('#doc_reg_insert_form').submit(function(e) {
				$('#loadingModal').modal('show');
				e.preventDefault();
				$.ajax({
					url: '<?php echo base_url(); ?>documents/registry/create',
					type: 'POST',
					data: new FormData(this),
					contentType: false,
					processData: false,
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 201) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
								showConfirmButton: false,
								timer: 1500
							}).then(function() {
								location.reload();
							});
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
					},

					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
					} // Fix: Moved closing parentheses to the correct place
				});
			});

			// edit_registry_btn click
			$('.table tbody').on("click", ".edit_registry_btn", function() {
				$('#loadingModal').modal('show');
				// get menu_item id
				var registry_id = $(this).attr('data-registry-id');
				// ajax call
				$.ajax({
					url: '<?php echo base_url(); ?>documents/registry/show/' + registry_id,
					type: 'GET',
					data: {},
					dataType: 'json',
					beforeSend: function() {
						$('#registryEditOffcanvas button[type="submit"]').attr('disabled', true);
						$('#registryEditOffcanvas button[type="submit"]').html('Please wait...');
					},
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							$('#registry_id_edit').val(response.data.id);
							$('#registry_name_edit').val(response.data.registry_name);
							$('#registry_name_old_edit').val(response.data.registry_name);
							$('#system_id_edit').val(response.data.system_id);
							$('#registryEditOffcanvas').offcanvas('show');
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}

						$('#registryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#registryEditOffcanvas button[type="submit"]').html('Update');
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
						$('#registryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#registryEditOffcanvas button[type="submit"]').html('Update');
					}
				});
			});

			$('#registry_update_form').submit(function(e) {
				$('#loadingModal').modal('show');
				e.preventDefault();
				// get registry_id
				var registry_id = $('#registry_id_edit').val();
				$.ajax({
					url: '<?php echo base_url(); ?>documents/registry/update/' + registry_id,
					type: 'PUT',
					data: {
						"registry_name_edit": $('#registry_name_edit').val(),
						"system_id": $('#system_id_edit').val(),
					},
					dataType: 'json',
					success: function(response) {
						$('#loadingModal').modal('hide');
						if (response.status == 200) {
							Swal.fire({
								icon: 'success',
								title: 'Success',
								text: response.message,
								showConfirmButton: false,
								timer: 1500
							}).then(function() {
								location.reload();
							});
						} else if (response.status <= 500) {
							Swal.fire({
								icon: 'warning',
								title: 'Warning',
								text: response.message,
							});
						} else if (response.status >= 500) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: response.message,
							});
						}
						$('#registryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#registryEditOffcanvas button[type="submit"]').html('Update');
					},

					error: function(jqXHR, textStatus, errorThrown) {
						$('#loadingModal').modal('hide');
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Something went wrong! Please try again later.',
						});
						$('#registryEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#registryEditOffcanvas button[type="submit"]').html('Update');
					} // Fix: Moved closing parentheses to the correct place
				});
			});


			// delete_registry_btn click
			$('.table tbody').on("click", ".delete_registry_btn", function() {
				Swal.fire({
					title: 'Please Confirm',
					html: "<label class='data-text'>Are you sure you want to delete this document registry ? Please note that this action cannot be undone, so proceed with caution.</label>",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonColor: '#d33',
					cancelButtonColor: '#3085d6',
					confirmButtonText: 'Yes, delete it!'
				}).then((result) => {
					if (result.isConfirmed) {
						$('#loadingModal').modal('show');
						// get registry_id 
						var registry_id = $(this).attr('data-registry-id');
						// ajax call
						$.ajax({
							url: '<?php echo base_url(); ?>documents/registry/delete/' + registry_id,
							type: 'DELETE',
							data: {},
							dataType: 'json',
							beforeSend: function() {
								$('.delete_registry_btn').attr('disabled', true);
								$('.delete_registry_btn').html('<i class="fa fa-spinner fa-spin"></i> Deleting...');
							},
							success: function(response) {
								$('#loadingModal').modal('hide');
								if (response.status == 200) {
									Swal.fire({
										icon: 'success',
										title: 'Success',
										text: response.message,
										showConfirmButton: false,
										timer: 1500
									}).then(function() {
										location.reload();
									});
								} else if (response.status <= 500) {
									Swal.fire({
										icon: 'warning',
										title: 'Warning',
										text: response.message,
									});
								} else if (response.status >= 500) {
									Swal.fire({
										icon: 'error',
										title: 'Oops...',
										text: response.message,
									});
								}
								$('.delete_registry_btn').attr('disabled', false);
								$('.delete_registry_btn').html('Delete');
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('#loadingModal').modal('hide');
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: 'Something went wrong! Please try again later.',
								});
								$('.delete_registry_btn').attr('disabled', false);
								$('.delete_registry_btn').html('Delete');
							}
						});
					}
				})

			});
		});
	</script>
</body>

</html>