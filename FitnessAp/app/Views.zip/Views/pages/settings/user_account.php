<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</strong></h3>
			</div>
			<p>Please wait...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid">

				<!-- <?php //echo $block_header; 
						?> -->

				<div class="row mt-4">
					<div class="col-md-10 d-flex">
						<h4 class="p-title">User Accounts</h4>
					</div>
				</div>

				<div class="row clearfix mt-3">
					<div class="col-md-12">
						<div class="card">
							<div class="d-flex border-bottom">
								<div class="me-auto">
									<div class="header p-0 py-2 pt-4 mx-3">
										<h2>Available User Accounts</h2>
										<span class="badge bg-dark mt-2"><?php echo count($user_accounts) . " items found." ?></span>
									</div>
								</div>
								<div class="d-flex justify-content-end align-items-center me-3">
									<button data-bs-toggle="offcanvas" data-bs-target="#userAccountOffcanvas" aria-controls="userAccountOffcanvas" class="btn btn-primary btn-sm" style="height: fit-content;">+ New User Account</button>
								</div>
							</div>
							<div class="body">
								<div class="table-responsive">
									<table class="table table-hover js-basic-example dataTable table-custom">
										<thead class="thead-dark">
											<tr>
												<th>#</th>
												<th>Profile Type</th>
												<th>Employee</th>
												<th>Username</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<!-- itertate through $admin array -->
											<?php
											$x = 1;
											foreach ($user_accounts as $account) {
											?>
												<tr style="width: 100%;">
													<td style="width: 10%;"><?php echo $x; ?></td>
													<td><?php echo $account['profile_type']; ?></td>
													<td><?php echo $account['employee_name']; ?></td>
													<td class="text-info"><?php echo $account['user']; ?></td>
													<td style="width: 5%;">
														<div class="dropup">
															<button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
																<i class="bi bi-three-dots-vertical"></i>
															</button>
															<ul class="dropdown-menu" style="z-index: 99999;">
																<li>
																	<a href="#" class="dropdown-item edit-user-account-btn"  data-user-account-id="<?php echo $account['id']; ?>" >Edit</a>
																</li>
																<?php
																// check if the user is an admin, then show delete btn
																if ($user_role == 1) {
																?>
																	<li><a class="dropdown-item text-danger delete-user-account-btn" href="#"  data-user-account-id="<?php echo $account['id']; ?>">Delete</a></li>
																<?php } ?>
															</ul>
														</div>
													</td>
												</tr>
											<?php
												$x++;
											}
											?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

		<!-- user accounts Create offcanvas -->
		<div class="offcanvas offcanvas-end" id="userAccountOffcanvas" aria-labelledby="userAccountOffcanvasLabel">
			<div class="offcanvas-header">
				<h5 id="userAccountOffcanvasLabel">Create User Account</h5>
				<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body">
				<div class="">

					<div class="">

						<form id="user_account_insert_form">
							<div class="">
								<div class="">
									<div class="row clearfix">
										<div class="col-md-12">
											<div class="px-2">
												<div class="header" style="margin-top: -10px;">
													<h2 class="my-4 c-header text-primary">Enter User Account Details</h2>
												</div>
												<div class="">
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Select Group Profile<font color="#FF0000"><strong>*</strong></font></label>
																<select name="group_profile" id="group_profile" class="js-example-basic-single form-control" style="width: 100%;" required>
																	<option value="0">Select a Profile...</option>
																	<?php
																	foreach ($group_profiles as $profile) {
																		echo '<option value="' . $profile['id'] . '">' . $profile['type'] . '</option>';
																	}
																	?>
																</select>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Select Staff Member<font color="#FF0000"><strong>*</strong></font></label>
																<select name="employee_id" id="employee_id" class="js-example-basic-single form-control" style="width: 100%;" required>
																	<option value="0">Select a Member...</option>
																	<?php
																	foreach ($members as $member) {
																		echo '<option value="' . $member['id'] . '">' . $member['name'] . '</option>';
																	}
																	?>
																</select>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Username<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="username" id="username" class="form-control" placeholder="" required>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Password<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="password" id="password" class="form-control" placeholder="" required>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<button type="submit" class="btn btn-primary px-5 my-3"><i class="bi bi-check-circle-fill"></i>&nbsp;&nbsp;Create</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>

				</div>
			</div>
		</div>

		<!-- menu_item Edit offcanvas -->
		<div class="offcanvas offcanvas-end" id="userAccountEditOffcanvas" aria-labelledby="userAccountEditOffcanvasLabel">
			<div class="offcanvas-header">
				<h5 id="userAccountEditOffcanvasLabel">Update Menu Item Details</h5>
				<button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
			</div>
			<div class="offcanvas-body">
				<div class="">

					<div class="">

						<form id="user_account_update_form">
							<div class="">
								<div class="">
									<div class="row clearfix">
										<div class="col-md-12">
											<div class="px-2">
												<div class="header" style="margin-top: -10px;">
													<h2 class="my-4 c-header text-primary">Enter User Account Details</h2>
												</div>
												<div class="">
													<!-- user_account id -->
													<input type="hidden" name="user_account_id_edit" id="user_account_id_edit" class="form-control" required>
													<!-- user_account id end -->
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Select Group Profile<font color="#FF0000"><strong>*</strong></font></label>
																<select name="group_profile_edit" id="group_profile_edit" class="js-example-basic-single form-control" style="width: 100%;" required>
																	<option value="0">Select a Profile...</option>
																	<?php
																	foreach ($group_profiles as $profile) {
																		echo '<option value="' . $profile['id'] . '">' . $profile['type'] . '</option>';
																	}
																	?>
																</select>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Select Staff Member<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="employee_id_edit_name" id="employee_id_edit_name" class="form-control" placeholder="" readonly>
																<input type="text" name="employee_id_edit" id="employee_id_edit" class="form-control" placeholder="" readonly hidden>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<div class="form-group">
																<label class="form-label">Username<font color="#FF0000"><strong>*</strong></font></label>
																<input type="text" name="username_edit" id="username_edit" class="form-control" placeholder="" readonly>
															</div>
														</div>
													</div>
													<div class="row clearfix">
														<div class="col-sm-12">
															<button type="submit" class="btn btn-primary px-5 my-3"><i class="bi bi-check-circle-fill"></i>&nbsp;&nbsp;Update</button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>

				</div>
			</div>
		</div>

	</div>

	<!-- Javascript -->
    <?= view('layouts/footer'); ?>

	<script>
		$('.js-example-basic-single').select2({
			placeholder: " Select",
			allowClear: true
		});
		// submit user_account_insert_form
		$('#user_account_insert_form').submit(function(e) {
			e.preventDefault();
			// ajax call
			$.ajax({
				url: '<?php echo base_url(); ?>settings/user_account/create',
				type: 'POST',
				data: new FormData(this),
				cache: false,
				contentType: false,
				processData: false,
				beforeSend: function() {
					$('#user_account_insert_form button[type="submit"]').attr('disabled', true);
					$('#user_account_insert_form button[type="submit"]').html('Please wait...');
				},
				success: function(data) {
					if (data.status == 201) {
						Swal.fire({
							icon: 'success',
							title: 'Success',
							text: data.message,
							showConfirmButton: false,
							timer: 1500
						}).then(function() {
							window.location.href = "<?php echo base_url(); ?>settings/user_account";
						});
					} else if (data.status == 400) {
						Swal.fire({
							icon: 'warning',
							title: 'Missing Data',
							text: data.message,
						});
					} else if (data.status == 409) {
						Swal.fire({
							icon: 'warning',
							title: 'Conflict',
							text: data.message,
						});
					} else if (data.status == 500) {
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: data.message,
						});
					}
					$('#user_account_insert_form button[type="submit"]').attr('disabled', false);
					$('#user_account_insert_form button[type="submit"]').html('Create');
				},
				error: function(jqXHR, textStatus, errorThrown) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Something went wrong! Please try again later.',
					});
					$('#user_account_insert_form button[type="submit"]').attr('disabled', false);
					$('#user_account_insert_form button[type="submit"]').html('Create');
				}
			});
		});

		// .edit-user-account-btn click
		$('.edit-user-account-btn').click(function() {
			// get menu_item id
			var user_account_id = $(this).attr('data-user-account-id');
			// ajax call
			$.ajax({
				url: '<?php echo base_url(); ?>settings/user_account/show/' + user_account_id,
				type: 'GET',
				data: {},
				dataType: 'json',
				beforeSend: function() {
					$('#userAccountEditOffcanvas button[type="submit"]').attr('disabled', true);
					$('#userAccountEditOffcanvas button[type="submit"]').html('Please wait...');
				},
				success: function(response) {
					if (response.status == 200) {
						// set user_account id
						$('#user_account_id_edit').val(response.data.id);
						// set username_edit
						$('#username_edit').val(response.data.user);
						// set group_profile_edit
						$('#group_profile_edit').val(response.data.group_id).trigger('change');
						// set employee_id_edit
						$('#employee_id_edit').val(response.data.emp_id);
						// set employee_id_edit_name
						$('#employee_id_edit_name').val(response.employee_name);
						// open offcanvas
						$('#userAccountEditOffcanvas').offcanvas('show');
						$('#userAccountEditOffcanvas button[type="submit"]').attr('disabled', false);
						$('#userAccountEditOffcanvas button[type="submit"]').html('Update');
					} else if (response.status == 404) {
						// not found
						Swal.fire({
							icon: 'warning',
							title: 'Not Found',
							text: response.message,
						});
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Something went wrong! Please try again later.',
					});
					$('#userAccountEditOffcanvas button[type="submit"]').attr('disabled', false);
					$('#userAccountEditOffcanvas button[type="submit"]').html('Update');
				}
			});
		});

		// submit menu_item_update_form
		$('#user_account_update_form').submit(function(e) {
			e.preventDefault();
			var id = $('#user_account_id_edit').val();
			// ajax call
			$.ajax({
				url: '<?php echo base_url(); ?>settings/user_account/update/' + id,
				type: 'PUT',
				data: $(this).serialize(),
				cache: false,
				processData: false,
				beforeSend: function() {
					$('#user_account_update_form button[type="submit"]').attr('disabled', true);
					$('#user_account_update_form button[type="submit"]').html('Please wait...');
				},
				success: function(data) {
					if (data.status == 201) {
						Swal.fire({
							icon: 'success',
							title: 'Success',
							text: data.message,
							showConfirmButton: false,
							timer: 1500
						}).then(function() {
							window.location.href = "<?php echo base_url(); ?>settings/user_account";
						});
					} else if (data.status == 400) {
						Swal.fire({
							icon: 'warning',
							title: 'Missing Data',
							text: data.message,
						});
					} else if (data.status == 409) {
						Swal.fire({
							icon: 'warning',
							title: 'Duplicate menu_item Name',
							text: data.message,
						});
					} else if (data.status == 500) {
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: data.message,
						});
					}
					$('#user_account_update_form button[type="submit"]').attr('disabled', false);
					$('#user_account_update_form button[type="submit"]').html('Create');
				},
				error: function(jqXHR, textStatus, errorThrown) {
					Swal.fire({
						icon: 'error',
						title: 'Oops...',
						text: 'Something went wrong! Please try again later.',
					});
					$('#user_account_update_form button[type="submit"]').attr('disabled', false);
					$('#user_account_update_form button[type="submit"]').html('Create');
				}
			});
		});

		// delete-user-account-btn click
		$('.delete-user-account-btn').click(function() {
			Swal.fire({
				title: 'Please Confirm',
				html: "<label class='data-text'>Are you sure you want to delete this User Account ? Please note that this action cannot be undone, so proceed with caution.</label>",
				icon: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#d33',
				cancelButtonColor: '#3085d6',
				confirmButtonText: 'Yes, delete it!'
			}).then((result) => {
				if (result.isConfirmed) {

					// get menu_item id
					var user_account_id = $(this).attr('data-user-account-id');
					// ajax call
					$.ajax({
						url: '<?php echo base_url(); ?>settings/user_account/delete/' + user_account_id,
						type: 'DELETE',
						data: {},
						dataType: 'json',
						beforeSend: function() {
							$('.delete-user-account-btn').attr('disabled', true);
							$('.delete-user-account-btn').html('<i class="fa fa-spinner fa-spin"></i>');
						},
						success: function(data) {
							if (data.status == 200) {
								Swal.fire({
									icon: 'success',
									title: 'Success',
									text: data.message,
									showConfirmButton: false,
									timer: 1500
								}).then(function() {
									window.location.href = "<?php echo base_url(); ?>settings/user_account";
								});
							} else if (data.status == 500) {
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: data.message,
								});
							}
							$('.delete-user-account-btn').attr('disabled', false);
							$('.delete-user-account-btn').html('<i class="fa fa-trash"></i>');
						},
						error: function(jqXHR, textStatus, errorThrown) {
							Swal.fire({
								icon: 'error',
								title: 'Oops...',
								text: 'Something went wrong! Please try again later.',
							});
							$('.delete-user-account-btn').attr('disabled', false);
							$('.delete-user-account-btn').html('<i class="fa fa-trash"></i>');
						}
					});
				}
			})

		});
	</script>
</body>

</html>