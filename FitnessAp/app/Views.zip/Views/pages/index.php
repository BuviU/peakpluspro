<?= view('layouts/header'); ?>

<body class="theme-cyan">

	<!-- Page Loader -->
	<div class="page-loader-wrapper">
		<div class="loader">
			<div class="m-t-30 mb-3">
				<h3 style="color: white;"><strong>:: EDMS ::</h3>
			</div>
			<p>Just a moment...</p>
		</div>
	</div>
	<!-- Overlay For Sidebars -->

	<div id="wrapper">

		<?= view('layouts/nav_bar'); ?>
		<?= view('layouts/sidebar'); ?>

		<div id="main-content">
			<div class="container-fluid p-3 pt-4">
				<?php
				$greeting_text = "";
				// time zone
				date_default_timezone_set('Asia/Colombo');
				// if morning, say good morning and so on
				if (date("H") < 12) {
					$greeting_text = "Good Morning";
				} else if (date("H") >= 12 && date("H") < 17) {
					$greeting_text = "Good Afternoon";
				} else if (date("H") >= 17 && date("H") < 19) {
					$greeting_text = "Good Evening";
				} else if (date("H") >= 19) {
					$greeting_text = "Good Night";
				}
				?>
				<h3 class="mb-3"><strong><?php echo $greeting_text; ?></strong></h3>
				<div class="d-flex justify-content-center" style="width: 100%; height: 150px; border-radius: 20px; background-image: linear-gradient(180deg, #003a9e, #003a9e);">
					<img src="<?php echo base_url(); ?>assets/images/dashboard_panel.jpg" alt="Logo" class="" style="border-radius: 20px;">
				</div>
				<div class="row" style="margin: 30px 0px;">
					<div class="col-md-4 col-sm-12 p-1">
						<div class="card">
							<div class="card-body">
								<div class="d-flex">
									<div class="d-flex">
										<img src="<?php echo base_url(); ?>/assets/images/upload-to-cloud-64.png" alt="upload-to-cloud-64">
									</div>
									<div class="d-flex flex-column ms-4">
										<h2 class="ps-0"><strong><?php echo $user_uploads_count; ?></strong></h2>
										<h6 style="font-weight: 600;" class="card-title">Your Uploads</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-12 p-1">
						<div class="card">
							<div class="card-body">
								<div class="d-flex">
									<div class="d-flex">
										<img src="<?php echo base_url(); ?>/assets/images/blind-64.png" alt="blind-64">
									</div>
									<div class="d-flex flex-column ms-4">
										<h2 class="ps-0"><strong><?php echo $unseen_mail_count; ?></strong></h2>
										<h6 style="font-weight: 600;" class="card-title">Unseen Mails</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-12 p-1">
						<div class="card">
							<div class="card-body">
								<div class="d-flex">
									<div class="d-flex">
										<img src="<?php echo base_url(); ?>/assets/images/send-64.png" alt="send-64">
									</div>
									<div class="d-flex flex-column ms-4">
										<h2 class="ps-0"><strong><?php echo $sent_mail_count; ?></strong></h2>
										<h6 style="font-weight: 600;" class="card-title">Sent Mails</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="row clearfix mt-4 pt-5">
					<div class="col-lg-12 col-md-12 pt-5 d-flex justify-content-center align-items-center">
						<img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo" class="img-responsive logo" style="width: 400px; opacity: 0.3;">
					</div>
				</div> -->
			</div>
		</div>

	</div>

	<!-- Javascript -->
	<script src="assets/bundles/libscripts.bundle.js"></script>
	<script src="assets/bundles/vendorscripts.bundle.js"></script>

	<script src="assets/bundles/chartist.bundle.js"></script>
	<script src="assets/bundles/knob.bundle.js"></script>
	<!-- Jquery Knob -->
	<script src="assets/bundles/flotscripts.bundle.js"></script>
	<!-- flot charts Plugin Js -->
	<script src="assets/vendor/toastr/toastr.js"></script>
	<script src="assets/vendor/flot-charts/jquery.flot.selection.js"></script>

	<script src="assets/bundles/mainscripts.bundle.js"></script>
	<script src="assets/js/index.js"></script>
</body>

</html>