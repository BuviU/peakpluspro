 <!-- Javascript -->
 <script src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
 <script src="<?php echo base_url(); ?>assets/bundles/libscripts.bundle.js"></script>
 <script src="<?php echo base_url(); ?>assets/bundles/vendorscripts.bundle.js"></script>
 <script src="<?php echo base_url(); ?>assets/select2/select2.full.min.js"></script>
 <script src="<?php echo base_url(); ?>assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script><!-- bootstrap datepicker Plugin Js -->

 <script src="<?php echo base_url(); ?>assets/bundles/easypiechart.bundle.js"></script>

 <script src="<?php echo base_url(); ?>assets/bundles/mainscripts.bundle.js"></script>
 <script src="<?php echo base_url(); ?>assets/bundles/datatablescripts.bundle.js"></script>
 <script src="<?php echo base_url(); ?>assets/js/pages/tables/jquery-datatable.js"></script>
 <script src="<?php echo base_url(); ?>assets/js/sweetalert2@11.js"></script>