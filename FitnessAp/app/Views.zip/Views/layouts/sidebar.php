<div id="left-sidebar" class="sidebar">
	<div class="sidebar-scroll">
		<div class="user-account">
			<img src="<?php if (isset($sidebar_employee_prof_pic) && $sidebar_employee_prof_pic != "") {
							echo base_url() . "assets/images/employees/" . $sidebar_employee_prof_pic;
						} else {
							echo base_url() . "assets/images/employees/user.png";
						} ?>" class="rounded-circle user-photo" width="50px" height="50px" alt="User Profile Picture">
			<div class="dropdown">
				<span style="font-weight: 400;">Welcome,</span>
				<a style="font-weight: 600;" href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong><?php echo $sidebar_employee_name; ?></strong></a>
				<ul class="dropdown-menu dropdown-menu-right account">
					<!-- <li><a href="doctor-profile.html"><i class="icon-user"></i>My Profile</a></li>
					<li class="divider"></li> -->
					<li><a href="<?php echo base_url(); ?>my_profile"><i class="icon-user"></i>My Profile</a></li>
					<li><a href="#" onclick="logout()"><i class="icon-power"></i>Logout</a></li>
				</ul>
			</div>
			<hr>
		</div>

		<!-- Tab panes -->
		<div class="p-l-0 p-r-0">
			<nav class="sidebar-nav">
				<ul class="main-menu metismenu">
					<!-- class="active" -->
					<li><a style="font-weight: 600;" href="<?php echo base_url(); ?>dashboard"><span>Dashboard</span></a></li>
					<!-- <li><a href="javascript:void(0);" class="has-arrow">Settings</span> </a>
						<ul>
							<li><a href="<?php echo base_url() ?>settings/group_profile">Group Profiles</a></li>
							<li><a href="<?php echo base_url() ?>settings/menu_category">Menu Categories</a></li>
							<li><a href="<?php echo base_url() ?>settings/menu_list">Menu List</a></li>
							<li><a href="<?php echo base_url() ?>settings/user_account">User Accounts</a></li>
							<li><a href="<?php echo base_url() ?>settings/group_privilege/0">Group Privileges</a></li>
						</ul>
					</li>
					<li><a href="javascript:void(0);" class="has-arrow">Registrations</span> </a>
						<ul>
							<li><a href="<?php echo base_url() ?>registrations/staff_member">Staff Members</a></li>
						</ul>
					</li> -->


					<?php
					foreach ($allowed_categories as $category) {
					?>
						<li><a href="javascript:void(0);" style="font-weight: 600;" class="has-arrow"><span><?php echo $category['category']; ?></span> </a>
							<ul>

								<?php
								foreach ($allowed_menu_list as $menu_item) {
									if ($category['cat_id'] == $menu_item['cat_id']) { ?>
										<li><a style="font-weight: 600;" href="<?php echo base_url() . $menu_item['url']; ?>"><?php echo $menu_item['menu']; ?></a></li>
								<?php }
								}
								?>

							</ul>
						</li>
					<?php } ?>

				</ul>
			</nav>
		</div>
	</div>
</div>

<script>
	function logout() {
		Swal.fire({
			title: 'Are you sure?',
			text: "You want to logout from the system?",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#00a65a',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, Logout!'
		}).then((result) => {
			if (result.isConfirmed) {
				$.ajax({
					url: "<?php echo base_url(); ?>logout",
					method: "GET",
					dataType: null,
					success: function(response) {
						if (response.status == 200) {
							let timerInterval;
							Swal.fire({
								title: "Please Wait...",
								html: response.msg,
								timer: 2000,
								timerProgressBar: false,
								didOpen: () => {
									Swal.showLoading();
								},
								willClose: () => {
									clearInterval(timerInterval);
								}
							}).then((result) => {
								// remove local storge items
								localStorage.removeItem('previousNotifications');
								// redirect to login page
								if (result.dismiss === Swal.DismissReason.timer) {
									var is_admin = "<?php echo session()->get('is_admin'); ?>"
									if (is_admin == 1) {
										window.location.href = "<?php echo base_url() ?>admin";
									} else {
										window.location.href = "<?php echo base_url() ?>";
									}
								}
							});

						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						Swal.fire({
							title: 'Error!',
							text: errorThrown,
							icon: 'error',
							confirmButtonColor: '#00a65a',
						});
					}
				});
			}
		});
	}
</script>

<!-- <li><a href="<?php echo base_url(); ?>Con_settings/group_profiles">Group Profiles</a></li>
<li><a href="<?php echo base_url(); ?>Con_settings/menu_category">Menu Category</a></li>
<li><a href="<?php echo base_url(); ?>Con_settings/menu_list">Menu List</a></li>
<li><a href="<?php echo base_url(); ?>Con_settings/group_privileges">Group Privileges</a></li>
<li><a href="<?php echo base_url(); ?>Con_settings/user_accounts">User Accounts</a></li>
<li><a href="<?php echo base_url(); ?>Con_settings/change_password">Change Password</a></li> -->