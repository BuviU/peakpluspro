<!doctype html>
<html lang="en">

<head>
    <title>:: NWSDB - EDMS ::</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Lucid Bootstrap 4.1.1 Admin Template">
    <meta name="author" content="WrapTheme, design by: ThemeMakker.com">

    <link rel="icon" href="/favicon.png" type="image/png">
	<!-- VENDOR CSS -->
	<link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/all.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/sweetalert/sweetalert.css" />
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/select2/select2.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-icons.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/dropify/css/dropify.min.css">	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/timeline.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/print.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/summernote/dist/summernote.css">
	<!-- <link rel="stylesheet" href="<?php echo base_url() ?>/assets/scannerjs/scanner.css"> -->

	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/color_skins.css">

	<style>
		.debug {
			border: 1px solid red;
		}
	</style>
</head>